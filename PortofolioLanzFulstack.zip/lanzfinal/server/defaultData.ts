export interface PortfolioData {
  hero: {
    greeting: string;
    name: string;
    title: string;
    tagline: string;
    bio: string;
    badges: string[];
    primaryCtaText: string;
    primaryCtaLink: string;
    secondaryCtaText: string;
    secondaryCtaLink: string;
    avatarUrl: string;
    statusText: string;
    statusAvailable: boolean;
  };
  navigation: {
    brandName: string;
    brandSubtext: string;
    menuItems: Array<{
      id: string;
      label: string;
      href: string;
      active: boolean;
    }>;
  };
  album: Array<{
    id: string;
    title: string;
    description: string;
    category: string;
    imageUrl: string;
    tags: string[];
    date: string;
    featured: boolean;
  }>;
  skills: Array<{
    category: string;
    description: string;
    items: Array<{
      name: string;
      level: number;
      badge: string;
      experience: string;
    }>;
  }>;
  profile: {
    headline: string;
    bioParagraphs: string[];
    manifesto: string;
    itVision: string;
    stats: Array<{
      label: string;
      value: string;
      description: string;
    }>;
    milestones: Array<{
      year: string;
      role: string;
      company: string;
      description: string;
    }>;
    downloadCvUrl: string;
  };
  siteConfig: {
    footerText: string;
    copyrightYear: string;
    contactEmail: string;
    contactPhone: string;
    githubUrl: string;
    linkedinUrl: string;
    twitterUrl: string;
    location: string;
  };
  socialLinks: Array<{
    id: string;
    platform: 'github' | 'linkedin' | 'twitter' | 'instagram' | 'youtube' | 'telegram' | 'discord' | 'website';
    label: string;
    url: string;
    active: boolean;
  }>;
}

export const initialPortfolioData: PortfolioData = {
  hero: {
    greeting: "HALO DUNIA, SAYA",
    name: "Lanz",
    title: "Pengembang Aplikasi & Website Developer",
    tagline: "Membangun Sistem Web Skala Besar Berperforma Tinggi dengan Ketahanan Siber Berlapis Baja.",
    bio: "Spesialis dalam arsitektur modern MERN / Next.js, Cloud Native, Zero-Trust Architecture, dan Secure Code Development. Memadukan estetika Neo-Brutalism dengan arsitektur backend yang kokoh.",
    badges: [
      "Zero-Trust Architecture",
      "MERN / Next.js Expert",
      "Offensive & Defensive Security",
      "High-Performance API"
    ],
    primaryCtaText: "Jelajahi Proyek",
    primaryCtaLink: "#album",
    secondaryCtaText: "Hubungi Langsung",
    secondaryCtaLink: "#kontak",
    avatarUrl: "https://files.catbox.moe/6uoe4p.svg",
    statusText: "SIAP UNTUK PROYEK HIGH-IMPACT & KONSULTASI SIBER",
    statusAvailable: true
  },
  navigation: {
    brandName: "LanzPortofolio",
    brandSubtext: "Pengembang Apk & Web",
    menuItems: [
      { id: "home", label: "Beranda", href: "#home", active: true },
      { id: "album", label: "Album & Galeri", href: "#album", active: true },
      { id: "skills", label: "Keahlian & Stack", href: "#skills", active: true },
      { id: "profile", label: "Profil & Visi IT", href: "#profile", active: true },
      { id: "kontak", label: "Kirim Pesan", href: "#kontak", active: true }
    ]
  },
  album: [
    {
      id: "alb-1",
      title: "SentryShield - Real-Time SOC & Threat Intelligence Dashboard",
      description: "Platform pemantauan ancaman keamanan siber real-time dengan integrasi SIEM, deteksi anomali paket data, dan mitigasi DDoS otomatis.",
      category: "Cybersecurity",
      imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80",
      tags: ["Node.js", "MongoDB", "SIEM", "Socket.io", "Docker"],
      date: "2026",
      featured: true
    },
    {
      id: "alb-2",
      title: "OmniLedger - Enterprise Distributed Fintech Engine",
      description: "Sistem transaksi keuangan multi-mata uang dengan enkripsi end-to-end AES-256-GCM, audit trail tamper-proof, dan arsitektur microservices berkecepatan tinggi.",
      category: "Fullstack Architecture",
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
      tags: ["Next.js", "TypeScript", "Redis", "MongoDB", "Tailwind CSS"],
      date: "2025",
      featured: true
    },
    {
      id: "alb-3",
      title: "CyberWarfare Lab & CTF Infrastructure",
      description: "Infrastruktur simulasi penyerangan dan pertahanan siber terisolasi dengan Docker sandbox otomatis untuk pelatihan tim red team & blue team.",
      category: "Cybersecurity",
      imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80",
      tags: ["CTF", "DevSecOps", "Linux Kernel", "Reverse Engineering"],
      date: "2025",
      featured: false
    },
    {
      id: "alb-4",
      title: "VortexCloud - Automated Edge Deployment Mesh",
      description: "Sistem CDN dan edge-routing cerdas dengan integrasi WebAssembly, TLS 1.3 hardening, dan kompresi aset otomatis berlatensi di bawah 15ms.",
      category: "Cloud & DevSecOps",
      imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80",
      tags: ["Go", "Kubernetes", "GraphQL", "Cloudflare Workers"],
      date: "2024",
      featured: true
    },
    {
      id: "alb-5",
      title: "ApexCommerce - Neo-Brutalist Headless Marketplace",
      description: "Platform e-commerce dengan checkout berkecepatan sub-detik, caching layer cerdas, dan desain Neo-Brutalism kontras tinggi.",
      category: "Frontend UI/UX",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80",
      tags: ["React 19", "Framer Motion", "Tailwind CSS", "Stripe API"],
      date: "2024",
      featured: false
    },
    {
      id: "alb-6",
      title: "Hardware Hack & IoT Security Testbench",
      description: "Stasiun uji penetrasi perangkat keras mikroprosesor IoT dengan penganalisa logika sinyal dan audit firmware nirkabel.",
      category: "Hardware & IoT",
      imageUrl: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80",
      tags: ["Firmware Analysis", "ESP32", "MQTT", "Hardware Security"],
      date: "2023",
      featured: false
    }
  ],
  skills: [
    {
      category: "Rekayasa Backend & Database",
      description: "Mendesain arsitektur server terdistribusi, API rate-limited, dan manajemen basis data berkinerja tinggi.",
      items: [
        { name: "Node.js / Express / NestJS", level: 96, badge: "Expert", experience: "6+ Tahun" },
        { name: "MongoDB / Mongoose", level: 94, badge: "Master", experience: "5+ Tahun" },
        { name: "PostgreSQL & Redis Caching", level: 90, badge: "Senior", experience: "4+ Tahun" },
        { name: "Microservices & Event-Driven (Kafka/RabbitMQ)", level: 88, badge: "Advanced", experience: "3+ Tahun" }
      ]
    },
    {
      category: "Keamanan Siber & DevSecOps",
      description: "Audit keamanan aplikasi, mitigasi OWASP Top 10, autentikasi berbasis kriptografi, dan hardening infrastruktur.",
      items: [
        { name: "Zero-Trust & Identity Access Management (JWT/OAuth2)", level: 98, badge: "Specialist", experience: "6+ Tahun" },
        { name: "Vulnerability Assessment & Penetration Testing", level: 92, badge: "Offensive", experience: "5+ Tahun" },
        { name: "CI/CD Pipeline Security & SAST/DAST", level: 90, badge: "DevSecOps", experience: "4+ Tahun" },
        { name: "Network Hardening, WAF, & Rate Limiting", level: 95, badge: "Shield", experience: "5+ Tahun" }
      ]
    },
    {
      category: "Frontend Modern & Interaktif",
      description: "Membangun antarmuka responsif cepat, animasi fluid, desain neo-brutalist khas, dan standar aksesibilitas tertinggi.",
      items: [
        { name: "React 19 & Next.js", level: 95, badge: "Expert", experience: "5+ Tahun" },
        { name: "Tailwind CSS & Neo-Brutalism System", level: 98, badge: "Stylist", experience: "4+ Tahun" },
        { name: "Framer Motion & Fluid Micro-Interactions", level: 92, badge: "Animator", experience: "3+ Tahun" },
        { name: "TypeScript Strict Mode", level: 96, badge: "Architect", experience: "5+ Tahun" }
      ]
    },
    {
      category: "Infrastruktur Cloud & Kontainer",
      description: "Orkestrasi kontainer, arsitektur serverless, dan pemantauan sistem produksi 99.99% uptime.",
      items: [
        { name: "Docker & Container Hardening", level: 94, badge: "Master", experience: "5+ Tahun" },
        { name: "Kubernetes & Cloud Native", level: 86, badge: "Advanced", experience: "3+ Tahun" },
        { name: "AWS & Google Cloud Platform", level: 89, badge: "Certified", experience: "4+ Tahun" },
        { name: "Linux System Internals & Shell Scripting", level: 95, badge: "Guru", experience: "7+ Tahun" }
      ]
    }
  ],
  profile: {
    headline: "Menciptakan Solusi Perangkat Lunak Yang Kokoh, Cepat, dan Kebal dari Ancaman Eksploitasi.",
    bioParagraphs: [
      "Saya adalah seorang Senior Fullstack Developer dan Cybersecurity Architect yang berdedikasi menciptakan ekosistem digital kelas dunia. Bagi saya, keindahan visual sebuah aplikasi web harus diimbangi oleh fondasi arsitektur backend yang kokoh serta pertahanan siber yang tanpa kompromi.",
      "Dengan pengalaman mendalam dalam ekosistem JavaScript/TypeScript modern, MongoDB, serta perancangan sistem terdistribusi, saya telah merancang berbagai aplikasi skala besar yang melayani jutaan request dengan latensi minimal dan standar proteksi setara institusi finansial.",
      "Gaya Neo-Brutalism yang saya usung di LanzPortofolio mencerminkan filosofi kerja saya: lugas, berani, berkarakter kuat, jujur dalam fungsi, tanpa menyembunyikan esensi teknologi di balik polesan semu."
    ],
    manifesto: "Kode yang baik bukan sekadar bekerja saat demo, tetapi tetap kokoh saat diserbu ribuan permintaan tak terduga dan tetap terlindungi ketika ada upaya eksploitasi di jam 3 pagi.",
    itVision: "Visi saya adalah memadukan kecerdasan rekayasa web mutakhir dengan kesadaran siber universal. Di era kecerdasan buatan dan komputasi awan yang serba cepat, keamanan bukanlah lapisan tambahan yang ditempel di akhir; melainkan DNA fundamental sejak baris kode pertama ditulis.",
    stats: [
      { label: "Proyek Terselesaikan", value: "48+", description: "Solusi end-to-end teruji di lingkungan produksi nyata." },
      { label: "Temuan Kerentanan Ditutup", value: "120+", description: "Audit keamanan tervalidasi dan diperbaiki tanpa cela." },
      { label: "Uptime Sistem Rata-rata", value: "99.98%", description: "Arsitektur tahan uji dengan redundansi berlapis." },
      { label: "Tahun Dedikasi IT", value: "7+", description: "Terus berevolusi menguasai teknologi terdepan." }
    ],
    milestones: [
      {
        year: "2024 - Sekarang",
        role: "Lead Cybersecurity Architect & Fullstack Consultant",
        company: "Lanz Digital Engineering",
        description: "Memimpin perancangan platform cloud-native berstandar ISO 27001 dan membangun aplikasi Next.js/React generasi terbaru."
      },
      {
        year: "2021 - 2024",
        role: "Senior Fullstack Engineer & DevSecOps Lead",
        company: "Nexus Core Systems",
        description: "Mengembangkan arsitektur API microservices dengan MongoDB sharding, caching Redis, dan integrasi pipeline keamanan otomatis."
      },
      {
        year: "2019 - 2021",
        role: "Backend & Security Specialist",
        company: "Vanguard Tech Labs",
        description: "Merancang API gateway aman, autentikasi multi-faktor berbasis FIDO2/WebAuthn, dan penanganan ribuan event data transaksi per detik."
      }
    ],
    downloadCvUrl: "#"
  },
  siteConfig: {
    footerText: "LanzPortofolio © 2026. Dibangun dengan estetika Neo-Brutalism, teknologi MERN Stack, dan ketahanan siber sejati.",
    copyrightYear: "2026",
    contactEmail: "contact@lanzportofolio.dev",
    contactPhone: "+62 812-3456-7890",
    githubUrl: "https://github.com/lanzportofolio",
    linkedinUrl: "https://linkedin.com/in/lanzportofolio",
    twitterUrl: "https://twitter.com/lanzportofolio",
    location: "Jakarta, Indonesia (Available Globally)"
  },
  socialLinks: [
    {
      id: "soc-1",
      platform: "github",
      label: "GitHub",
      url: "https://github.com/lanzportofolio",
      active: true
    },
    {
      id: "soc-2",
      platform: "linkedin",
      label: "LinkedIn",
      url: "https://linkedin.com/in/lanzportofolio",
      active: true
    },
    {
      id: "soc-3",
      platform: "twitter",
      label: "Twitter / X",
      url: "https://twitter.com/lanzportofolio",
      active: true
    },
    {
      id: "soc-4",
      platform: "instagram",
      label: "Instagram",
      url: "https://instagram.com/lanzportofolio",
      active: true
    },
    {
      id: "soc-5",
      platform: "youtube",
      label: "YouTube",
      url: "https://youtube.com/@lanzportofolio",
      active: false
    },
    {
      id: "soc-6",
      platform: "telegram",
      label: "Telegram",
      url: "https://t.me/lanzportofolio",
      active: true
    },
    {
      id: "soc-7",
      platform: "discord",
      label: "Discord",
      url: "https://discord.gg/lanzportofolio",
      active: true
    }
  ]
};
