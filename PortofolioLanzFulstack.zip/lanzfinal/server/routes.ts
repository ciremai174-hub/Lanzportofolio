import { Router, Request, Response } from 'express';
import rateLimit from 'express-rate-limit';
import { cleanXSS } from './auth.js';

const router = Router();

// Rate limiters for DDoS & Spam Protection
export const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Terlalu banyak permintaan kirim pesan dari IP Anda. Silakan coba lagi dalam beberapa menit.',
    code: 'RATE_LIMIT_EXCEEDED',
  },
});

// System Health & Architecture Status (100% Firebase Native)
router.get('/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ONLINE',
    system: 'LanzPortofolio Cyber Architecture',
    database: {
      provider: 'Google Firebase Cloud Firestore & Firebase Auth',
      mode: 'CLIENT_NATIVE_REALTIME',
      securityRules: 'Zero-Trust RBAC Enforced',
      status: 'CONNECTED',
    },
    timestamp: new Date().toISOString(),
  });
});

// Fallback contact endpoint (primary submission handled directly by Firebase Web SDK)
router.post('/contact', contactLimiter, (req: Request, res: Response) => {
  try {
    const { name, email, subject, message } = req.body || {};

    if (!name || typeof name !== 'string' || name.trim().length < 2) {
      return res.status(400).json({ error: 'Nama pengirim minimal 2 karakter.' });
    }

    if (!email || typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return res.status(400).json({ error: 'Format alamat email tidak valid.' });
    }

    if (!message || typeof message !== 'string' || message.trim().length < 5) {
      return res.status(400).json({ error: 'Isi pesan minimal 5 karakter.' });
    }

    res.status(200).json({
      success: true,
      message: 'Pesan telah diterima oleh gateway server LanzPortofolio.',
      data: {
        name: cleanXSS(name),
        subject: cleanXSS(subject || 'Pesan Portofolio'),
        receivedAt: new Date().toISOString(),
      },
    });
  } catch (error: any) {
    res.status(500).json({ error: 'Gagal memproses pesan: ' + error.message });
  }
});

export default router;
