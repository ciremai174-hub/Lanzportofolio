export interface PortfolioData {
  hero: {
    greeting: string;
    name: string;
    title: string;
    tagline: string;
    bio: string;
    badges: string[];
    primaryCtaText: string;
    primaryCtaLink: string;
    secondaryCtaText: string;
    secondaryCtaLink: string;
    avatarUrl: string;
    statusText: string;
    statusAvailable: boolean;
  };
  navigation: {
    brandName: string;
    brandSubtext: string;
    menuItems: Array<{
      id: string;
      label: string;
      href: string;
      active: boolean;
    }>;
  };
  album: Array<{
    id: string;
    title: string;
    description: string;
    category: string;
    imageUrl: string;
    tags: string[];
    date: string;
    featured: boolean;
  }>;
  skills: Array<{
    category: string;
    description: string;
    items: Array<{
      name: string;
      level: number;
      badge: string;
      experience: string;
    }>;
  }>;
  profile: {
    headline: string;
    bioParagraphs: string[];
    manifesto: string;
    itVision: string;
    stats: Array<{
      label: string;
      value: string;
      description: string;
    }>;
    milestones: Array<{
      year: string;
      role: string;
      company: string;
      description: string;
    }>;
    downloadCvUrl: string;
  };
  siteConfig: {
    footerText: string;
    copyrightYear: string;
    contactEmail: string;
    contactPhone: string;
    githubUrl: string;
    linkedinUrl: string;
    twitterUrl: string;
    location: string;
    pageTitle?: string;
    pageDescription?: string;
    backgroundColor?: string;
    textColor?: string;
    accentColor?: string;
    customCss?: string;
    maintenanceMode?: boolean;
    maintenanceMessage?: string;
    faviconUrl?: string;
    pageCopy?: Record<string, string>;
    sectionOrder?: string[];
    hiddenSections?: string[];
    customSections?: Array<{
      id: string;
      eyebrow: string;
      title: string;
      body: string;
      imageUrl: string;
      buttonText: string;
      buttonUrl: string;
      backgroundColor: string;
      visible: boolean;
    }>;
  };
  socialLinks: Array<{
    id: string;
    platform: 'github' | 'linkedin' | 'twitter' | 'instagram' | 'youtube' | 'telegram' | 'discord' | 'website';
    label: string;
    url: string;
    active: boolean;
  }>;
}

export interface SocialLink {
  id: string;
  platform: 'github' | 'linkedin' | 'twitter' | 'instagram' | 'youtube' | 'telegram' | 'discord' | 'website';
  label: string;
  url: string;
  active: boolean;
}

export interface AdminUser {
  id: string;
  username: string;
  role: 'superadmin' | 'admin';
  createdAt?: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: 'unread' | 'read' | 'replied';
  ip?: string;
  createdAt: string;
}

export interface DatabaseStatus {
  database: string;
  isFirebaseConnected?: boolean;
  provider?: string;
  error?: string | null;
}
