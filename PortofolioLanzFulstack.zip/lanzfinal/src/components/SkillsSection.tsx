import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Cpu, ShieldCheck, Terminal, Layers, CheckCircle2, Award, Zap } from 'lucide-react';
import { PortfolioData } from '../types';
import { smoothEase, StaggerHeading, StaggerParagraph, RevealCard } from './motion/MotionText';

interface SkillsSectionProps {
  skills: PortfolioData['skills'];
  pageCopy?: Record<string, string>;
}

export const SkillsSection: React.FC<SkillsSectionProps> = ({ skills, pageCopy = {} }) => {
  const [activeCategoryIndex, setActiveCategoryIndex] = useState<number>(0);

  const getCategoryIcon = (index: number) => {
    switch (index) {
      case 0:
        return Terminal;
      case 1:
        return ShieldCheck;
      case 2:
        return Layers;
      default:
        return Cpu;
    }
  };

  return (
    <section id="skills" className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Title with Staggered Reveal */}
        <div className="max-w-3xl mb-12">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: smoothEase }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-300 text-[#09090B] border-2 border-[#09090B] neo-shadow-sm text-xs font-black uppercase font-mono tracking-wider mb-3"
          >
            <Zap className="w-3.5 h-3.5 text-[#2563EB]" />
            {pageCopy.skillsEyebrow || 'KOMPETENSI TEKNOLOGI INTI'}
          </motion.div>

          <h2 className="text-3xl sm:text-5xl font-black text-[#09090B] tracking-tight font-['Space_Grotesk']">
            <StaggerHeading text={pageCopy.skillsTitle || "Keahlian & Radar Teknologi Modern"} as="span" />
          </h2>

          <StaggerParagraph
            text={pageCopy.skillsDescription || "Kombinasi mendalam antara arsitektur backend berdaya tahan tinggi, rekayasa siber zero-trust, dan ekosistem frontend reaktif modern."}
            className="text-zinc-600 font-medium mt-3 text-sm sm:text-base leading-relaxed"
          />
        </div>

        {/* Category Selector Tabs with Stagger */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-10">
          {skills.map((cat, idx) => {
            const Icon = getCategoryIcon(idx);
            const isSelected = activeCategoryIndex === idx;

            return (
              <motion.button
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.08, ease: smoothEase }}
                onClick={() => setActiveCategoryIndex(idx)}
                className={`p-4 border-3 border-[#09090B] text-left transition-all ${
                  isSelected
                    ? 'bg-[#2563EB] text-white neo-shadow -translate-x-0.5 -translate-y-0.5'
                    : 'bg-white text-[#09090B] neo-shadow-sm hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div
                    className={`p-1.5 border-2 border-[#09090B] ${
                      isSelected ? 'bg-white text-[#2563EB]' : 'bg-yellow-300 text-[#09090B]'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 border border-[#09090B] ${
                      isSelected ? 'bg-black text-white' : 'bg-slate-100 text-zinc-600'
                    }`}
                  >
                    {cat.items.length} STACK
                  </span>
                </div>
                <h3 className="font-black text-sm font-['Space_Grotesk'] leading-tight">
                  {cat.category}
                </h3>
              </motion.button>
            );
          })}
        </div>

        {/* Active Category Detail Card with Fluid Stagger */}
        {skills[activeCategoryIndex] && (
          <motion.div
            key={activeCategoryIndex}
            initial={{ opacity: 0, y: 20, scale: 0.99 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.45, ease: smoothEase }}
            className="bg-white border-3 border-[#09090B] neo-shadow-lg p-6 sm:p-8"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b-2 border-[#09090B] mb-8">
              <div>
                <h3 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk'] flex items-center gap-2">
                  {skills[activeCategoryIndex].category}
                </h3>
                <p className="text-zinc-600 text-sm mt-1">
                  {skills[activeCategoryIndex].description}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="px-3 py-1 bg-emerald-100 text-emerald-800 border-2 border-[#09090B] text-xs font-mono font-bold flex items-center gap-1.5 neo-shadow-sm">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  AUDIT STANDAR INDUSTRI
                </span>
              </div>
            </div>

            {/* Grid of skill meters */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {skills[activeCategoryIndex].items.map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.08, duration: 0.5, ease: smoothEase }}
                  className="bg-slate-50 border-2 border-[#09090B] p-4 neo-shadow-sm flex flex-col justify-between space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-black text-[#09090B] text-base font-['Space_Grotesk']">
                        {item.name}
                      </h4>
                      <p className="text-zinc-500 text-xs font-mono">
                        {pageCopy.skillsExperiencePrefix || 'Pengalaman Praktis:'} {item.experience}
                      </p>
                    </div>

                    <span className="px-2 py-0.5 bg-[#2563EB] text-white border border-[#09090B] text-[11px] font-mono font-bold">
                      {item.badge}
                    </span>
                  </div>

                  {/* Progress Meter with Flowing Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono font-bold text-zinc-700">
                      <span>{pageCopy.skillsMeterLabel || 'KEMAHIRAN'}</span>
                      <span>{item.level}%</span>
                    </div>
                    <div className="w-full h-3 bg-zinc-200 border-2 border-[#09090B] overflow-hidden p-[1px]">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${item.level}%` }}
                        transition={{ duration: 0.8, delay: 0.15 + idx * 0.06, ease: smoothEase }}
                        className="h-full bg-[#2563EB]"
                      />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Bottom Cyber Security Guarantee */}
            <div className="mt-8 pt-6 border-t-2 border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-zinc-600">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-[#2563EB]" />
                <span>{pageCopy.skillsFooterText || 'Seluruh implementasi stack diaudit dengan prinsip Defense-in-Depth & Zero-Trust.'}</span>
              </div>
              <span className="font-bold text-[#09090B]">{pageCopy.skillsVerifiedLabel || 'TERVERIFIKASI PRODUKSI'}</span>
            </div>
          </motion.div>
        )}

      </div>
    </section>
  );
};
