import React from 'react';
import { motion } from 'motion/react';
import { User, Eye, Quote, TrendingUp } from 'lucide-react';
import { PortfolioData } from '../types';
import { smoothEase, StaggerHeading, StaggerParagraph, RevealCard } from './motion/MotionText';

interface ProfileSectionProps {
  data: PortfolioData['profile'];
  pageCopy?: Record<string, string>;
}

export const ProfileSection: React.FC<ProfileSectionProps> = ({ data, pageCopy = {} }) => {
  return (
    <section id="profile" className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-white border-t-3 border-[#09090B]">
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Section Header with Staggered Reveal */}
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: smoothEase }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-[#2563EB] text-white border-2 border-[#09090B] neo-shadow-sm text-xs font-black uppercase font-mono tracking-wider mb-3"
          >
            <User className="w-3.5 h-3.5" />
            {pageCopy.profileEyebrow || 'ARSITEK & FILOSOFI REKAYASA'}
          </motion.div>

          <h2 className="text-3xl sm:text-5xl font-black text-[#09090B] tracking-tight font-['Space_Grotesk']">
            <StaggerHeading text={pageCopy.profileTitle || "Profil & Visi IT Mendalam"} as="span" />
          </h2>

          <StaggerParagraph
            text={pageCopy.profileDescription || "Membangun ekosistem digital yang tidak hanya memikat di mata, namun berdaya tahan baja di balik layar."}
            className="text-zinc-600 font-medium mt-3 text-sm sm:text-base leading-relaxed"
          />
        </div>

        {/* Headline & Story Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Bio & Manifesto */}
          <div className="lg:col-span-7 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, ease: smoothEase }}
              className="bg-slate-50 border-3 border-[#09090B] neo-shadow p-6 sm:p-8 space-y-4"
            >
              <h3 className="text-xl sm:text-2xl font-black text-[#09090B] font-['Space_Grotesk'] leading-snug">
                {data.headline}
              </h3>

              <div className="space-y-3 text-zinc-700 text-sm sm:text-base leading-relaxed">
                {data.bioParagraphs.map((para, idx) => (
                  <motion.p
                    key={idx}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.1, duration: 0.6, ease: smoothEase }}
                  >
                    {para}
                  </motion.p>
                ))}
              </div>

              {/* Manifesto Quote with Stagger */}
              <div className="pt-4 border-t-2 border-[#09090B] mt-4">
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.25, duration: 0.6, ease: smoothEase }}
                  className="bg-amber-100 border-2 border-[#09090B] p-4 neo-shadow-sm relative"
                >
                  <Quote className="w-6 h-6 text-[#2563EB] absolute -top-3 -left-3 bg-white border-2 border-[#09090B] p-1" />
                  <p className="italic font-bold text-[#09090B] text-sm sm:text-base pl-2 leading-relaxed">
                    "{data.manifesto}"
                  </p>
                  <p className="text-right text-[11px] font-mono font-bold text-zinc-600 mt-2">
                    {pageCopy.profileManifestoLabel || '— LANZ // CYBERSECURITY MANIFESTO'}
                  </p>
                </motion.div>
              </div>
            </motion.div>

            {/* IT Vision Box */}
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2, duration: 0.7, ease: smoothEase }}
              className="bg-[#09090B] text-white border-3 border-[#09090B] neo-shadow-blue p-6 sm:p-8 space-y-3"
            >
              <div className="flex items-center gap-2 text-[#2563EB] font-mono text-xs font-bold uppercase">
                <Eye className="w-4 h-4" />
                <span>{pageCopy.profileVisionLabel || 'VISI TEKNOLOGI & MASA DEPAN SIBER'}</span>
              </div>
              <h4 className="text-xl font-black font-['Space_Grotesk']">
                {pageCopy.profileManifestoTitle || 'Keamanan Bukan Tambahan, Melainkan DNA Sejak Baris Pertama.'}
              </h4>
              <p className="text-zinc-300 text-sm sm:text-base leading-relaxed">
                {data.itVision}
              </p>
            </motion.div>
          </div>

          {/* Right: Stats & Experience Milestones */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Stats Numbers */}
            <div className="grid grid-cols-2 gap-4">
              {data.stats.map((stat, idx) => (
                <RevealCard key={idx} index={idx}>
                  <div className="bg-white border-3 border-[#09090B] p-4 sm:p-5 neo-shadow flex flex-col justify-between h-full">
                    <div className="text-3xl sm:text-4xl font-black text-[#2563EB] font-['Space_Grotesk']">
                      {stat.value}
                    </div>
                    <div className="mt-2">
                      <h5 className="font-black text-xs sm:text-sm text-[#09090B] uppercase font-mono">
                        {stat.label}
                      </h5>
                      <p className="text-[11px] text-zinc-500 mt-1 leading-tight">
                        {stat.description}
                      </p>
                    </div>
                  </div>
                </RevealCard>
              ))}
            </div>

            {/* Milestones Timeline */}
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3, duration: 0.7, ease: smoothEase }}
              className="bg-white border-3 border-[#09090B] neo-shadow p-6"
            >
              <div className="flex items-center justify-between pb-4 border-b-2 border-[#09090B] mb-6">
                <h4 className="text-lg font-black text-[#09090B] font-['Space_Grotesk'] flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-[#2563EB]" />
                  {pageCopy.profileTimelineTitle || 'Jejak Karir & Pengalaman'}
                </h4>
                <span className="text-xs font-mono font-bold text-zinc-500">PRODUKSI</span>
              </div>

              <div className="space-y-6">
                {data.milestones.map((m, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, x: -15 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: idx * 0.12, duration: 0.6, ease: smoothEase }}
                    className="relative pl-6 border-l-2 border-[#2563EB]"
                  >
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-white border-2 border-[#09090B] flex items-center justify-center">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#2563EB]" />
                    </div>

                    <span className="inline-block px-2 py-0.5 bg-slate-100 text-[#09090B] border border-[#09090B] text-[10px] font-mono font-bold uppercase mb-1">
                      {m.year}
                    </span>

                    <h5 className="font-black text-sm text-[#09090B] font-['Space_Grotesk']">
                      {m.role}
                    </h5>
                    <p className="text-xs font-bold text-[#2563EB]">{m.company}</p>
                    <p className="text-xs text-zinc-600 mt-1 leading-relaxed">
                      {m.description}
                    </p>
                  </motion.div>
                ))}
              </div>
            </motion.div>

          </div>
        </div>

      </div>
    </section>
  );
};
