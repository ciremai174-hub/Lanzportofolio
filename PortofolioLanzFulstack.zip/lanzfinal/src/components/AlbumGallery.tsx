import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Image as ImageIcon, Calendar, Maximize2, X, ShieldCheck } from 'lucide-react';
import { PortfolioData } from '../types';
import { smoothEase, StaggerHeading, StaggerParagraph, RevealCard } from './motion/MotionText';

interface AlbumGalleryProps {
  items: PortfolioData['album'];
  pageCopy?: Record<string, string>;
}

export const AlbumGallery: React.FC<AlbumGalleryProps> = ({ items, pageCopy = {} }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activeItem, setActiveItem] = useState<PortfolioData['album'][0] | null>(null);

  // Extract unique categories
  const categories = ['Semua', ...Array.from(new Set(items.map((i) => i.category)))];

  const filteredItems =
    selectedCategory === 'Semua'
      ? items
      : items.filter((item) => item.category === selectedCategory);

  return (
    <section id="album" className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-slate-100 border-t-3 border-b-3 border-[#09090B]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header with Staggered Reveal */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, ease: smoothEase }}
              className="inline-flex items-center gap-2 px-3 py-1 bg-[#2563EB] text-white border-2 border-[#09090B] neo-shadow-sm text-xs font-black uppercase font-mono tracking-wider mb-3"
            >
              <ImageIcon className="w-3.5 h-3.5" />
              {pageCopy.albumEyebrow || 'GALERI DOKUMENTASI & PROYEK'}
            </motion.div>

            <h2 className="text-3xl sm:text-5xl font-black text-[#09090B] tracking-tight font-['Space_Grotesk']">
              <StaggerHeading text={pageCopy.albumTitle || "Album & Rekam Jejak Arsitektur"} as="span" />
            </h2>

            <StaggerParagraph
              text={pageCopy.albumDescription || "Koleksi visual arsitektur sistem, infrastruktur siber, simulasi CTF, dan aplikasi berskala besar yang dikelola secara dinamis via Firebase Firestore."}
              className="text-zinc-600 font-medium mt-3 text-sm sm:text-base leading-relaxed"
            />
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2, ease: smoothEase }}
            className="flex items-center gap-2 text-xs font-mono font-bold bg-white border-2 border-[#09090B] px-3.5 py-2 neo-shadow-sm self-start md:self-auto"
          >
            <span className="w-2 h-2 rounded-full bg-[#2563EB]" />
            <span>{pageCopy.albumCounterLabel || 'TOTAL DOKUMEN'}: {filteredItems.length} {pageCopy.albumCounterSuffix || 'ITEM'}</span>
          </motion.div>
        </div>

        {/* Category Filters with Stagger */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1, ease: smoothEase }}
          className="flex flex-wrap gap-2 mb-10"
        >
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs sm:text-sm font-black uppercase tracking-wider font-mono border-2 border-[#09090B] transition-all ${
                  isSelected
                    ? 'bg-[#2563EB] text-white neo-shadow -translate-x-0.5 -translate-y-0.5'
                    : 'bg-white text-[#09090B] hover:bg-slate-200 active:translate-x-0'
                }`}
              >
                {cat}
              </button>
            );
          })}
        </motion.div>

        {/* Gallery Cards Grid with Smooth Staggered Reveal */}
        {filteredItems.length === 0 ? (
          <div className="bg-white border-3 border-[#09090B] neo-shadow p-12 text-center">
            <ImageIcon className="w-12 h-12 text-zinc-400 mx-auto mb-3" />
            <h3 className="text-xl font-black font-['Space_Grotesk']">{pageCopy.albumEmptyTitle || 'Belum ada item di kategori ini'}</h3>
            <p className="text-zinc-500 text-sm mt-1">
              {pageCopy.albumEmptyDescription || 'Tambahkan galeri baru melalui Panel Admin CMS Firebase.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredItems.map((item, index) => (
              <RevealCard key={item.id} index={index}>
                <div className="bg-white border-3 border-[#09090B] neo-shadow flex flex-col group hover:-translate-x-1 hover:-translate-y-1 hover:shadow-[7px_7px_0px_#09090B] transition-all duration-200 h-full">
                  {/* Image Header with Badge Overlay */}
                  <div
                    className="relative aspect-[16/10] overflow-hidden border-b-3 border-[#09090B] bg-slate-900 cursor-pointer"
                    onClick={() => setActiveItem(item)}
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                    <div className="absolute top-2.5 left-2.5">
                      <span className="px-2.5 py-1 bg-yellow-300 text-[#09090B] border-2 border-[#09090B] text-[11px] font-black uppercase font-mono neo-shadow-sm">
                        {item.category}
                      </span>
                    </div>

                    {item.featured && (
                      <div className="absolute top-2.5 right-2.5">
                        <span className="px-2 py-0.5 bg-[#2563EB] text-white border-2 border-[#09090B] text-[10px] font-black uppercase font-mono flex items-center gap-1 neo-shadow-sm">
                          <ShieldCheck className="w-3 h-3" />
                          FEATURED
                        </span>
                      </div>
                    )}

                    <div className="absolute inset-0 bg-[#09090B]/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <button className="px-3.5 py-2 bg-white text-[#09090B] border-2 border-[#09090B] text-xs font-black uppercase font-mono neo-shadow flex items-center gap-1.5">
                        <Maximize2 className="w-3.5 h-3.5 text-[#2563EB]" />
                        Lihat Rinci
                      </button>
                    </div>
                  </div>

                  {/* Card Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-zinc-500 font-mono text-xs">
                        <Calendar className="w-3.5 h-3.5 text-[#2563EB]" />
                        <span>{item.date}</span>
                      </div>
                      <h3 className="text-lg font-black text-[#09090B] font-['Space_Grotesk'] leading-snug group-hover:text-[#2563EB] transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-zinc-600 text-xs sm:text-sm leading-relaxed line-clamp-3">
                        {item.description}
                      </p>
                    </div>

                    {/* Tags */}
                    <div className="pt-3 border-t-2 border-slate-200">
                      <div className="flex flex-wrap gap-1.5">
                        {item.tags.map((tag, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-0.5 bg-slate-100 text-zinc-700 border border-[#09090B] text-[11px] font-mono font-bold"
                          >
                            #{tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </RevealCard>
            ))}
          </div>
        )}

        {/* Lightbox Modal */}
        <AnimatePresence>
          {activeItem && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                transition={{ duration: 0.35, ease: smoothEase }}
                className="bg-white border-3 border-[#09090B] neo-shadow-lg w-full max-w-3xl overflow-hidden max-h-[90vh] flex flex-col"
              >
                {/* Modal Header */}
                <div className="p-4 bg-[#2563EB] text-white border-b-3 border-[#09090B] flex items-center justify-between">
                  <div className="flex items-center gap-2 font-mono text-xs font-bold uppercase">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                    <span>DOKUMEN DETAIL // {activeItem.category}</span>
                  </div>
                  <button
                    onClick={() => setActiveItem(null)}
                    className="p-1 bg-white text-[#09090B] border-2 border-[#09090B] hover:bg-red-500 hover:text-white transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Modal Body */}
                <div className="overflow-y-auto p-5 sm:p-6 space-y-5">
                  <div className="border-3 border-[#09090B] overflow-hidden bg-slate-900 neo-shadow-sm max-h-[380px]">
                    <img
                      src={activeItem.imageUrl}
                      alt={activeItem.title}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="px-3 py-1 bg-yellow-300 text-[#09090B] border-2 border-[#09090B] text-xs font-black uppercase font-mono">
                        {activeItem.category}
                      </span>
                      <span className="text-xs font-mono font-bold text-zinc-500">
                        DIREKAM PADA TAHUN: {activeItem.date}
                      </span>
                    </div>

                    <h3 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                      {activeItem.title}
                    </h3>

                    <p className="text-zinc-700 text-sm sm:text-base leading-relaxed">
                      {activeItem.description}
                    </p>
                  </div>

                  {/* Tech stack badges */}
                  <div className="pt-4 border-t-2 border-[#09090B]">
                    <p className="text-xs font-mono font-bold uppercase text-zinc-500 mb-2">
                      TEKNOLOGI & INFRASTRUKTUR YANG DIGUNAKAN:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {activeItem.tags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="px-2.5 py-1 bg-[#2563EB] text-white border-2 border-[#09090B] text-xs font-mono font-bold neo-shadow-sm"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Modal Footer */}
                <div className="p-4 bg-slate-50 border-t-2 border-[#09090B] flex justify-end">
                  <button
                    onClick={() => setActiveItem(null)}
                    className="px-5 py-2 bg-[#09090B] text-white font-bold text-xs uppercase font-mono border-2 border-[#09090B] neo-shadow hover:bg-zinc-800"
                  >
                    Tutup Pratinjau
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};
