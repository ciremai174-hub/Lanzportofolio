import React from 'react';
import { motion, Variants, Transition } from 'motion/react';

// Premium high-precision easing curves and natural spring physics
export const slickEase = [0.16, 1, 0.3, 1] as const;
export const smoothEase = [0.22, 1, 0.36, 1] as const;

export const springSmooth: Transition = {
  type: 'spring',
  damping: 24,
  stiffness: 200,
  mass: 0.6,
};

export const springTactile: Transition = {
  type: 'spring',
  damping: 18,
  stiffness: 260,
  mass: 0.5,
};

export const containerStagger: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.06,
    },
  },
};

export const itemFadeUp: Variants = {
  hidden: {
    opacity: 0,
    y: 24,
    filter: 'blur(4px)',
  },
  visible: {
    opacity: 1,
    y: 0,
    filter: 'blur(0px)',
    transition: {
      duration: 0.7,
      ease: slickEase,
    },
  },
};

export const wordStaggerContainer: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.035,
      delayChildren: 0.04,
    },
  },
};

export const wordReveal: Variants = {
  hidden: {
    opacity: 0,
    y: '100%',
    rotateZ: 1.5,
    filter: 'blur(3px)',
  },
  visible: {
    opacity: 1,
    y: '0%',
    rotateZ: 0,
    filter: 'blur(0px)',
    transition: {
      duration: 0.75,
      ease: slickEase,
    },
  },
};

interface StaggerHeadingProps {
  text: string;
  className?: string;
  highlightWord?: string;
  highlightClass?: string;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span';
}

export const StaggerHeading: React.FC<StaggerHeadingProps> = ({
  text,
  className = '',
  highlightWord,
  highlightClass = 'text-[#2563EB]',
}) => {
  const words = text.split(' ');

  return (
    <motion.span
      variants={wordStaggerContainer}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: '-40px' }}
      className={`inline-block flex-wrap transform-gpu will-change-transform ${className}`}
    >
      {words.map((word, idx) => {
        const isHighlight = highlightWord && word.toLowerCase().includes(highlightWord.toLowerCase());
        return (
          <span key={idx} className="inline-block overflow-hidden mr-[0.25em] align-top py-0.5">
            <motion.span
              variants={wordReveal}
              className={`inline-block ${isHighlight ? highlightClass : ''}`}
            >
              {word}
            </motion.span>
          </span>
        );
      })}
    </motion.span>
  );
};

interface StaggerParagraphProps {
  text: string;
  className?: string;
  delay?: number;
}

export const StaggerParagraph: React.FC<StaggerParagraphProps> = ({
  text,
  className = '',
  delay = 0.1,
}) => {
  return (
    <motion.p
      initial={{ opacity: 0, y: 18, filter: 'blur(3px)' }}
      whileInView={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
      viewport={{ once: true, margin: '-40px' }}
      transition={{ duration: 0.75, delay, ease: slickEase }}
      className={`transform-gpu will-change-transform ${className}`}
    >
      {text}
    </motion.p>
  );
};

export const RevealCard: React.FC<{
  children: React.ReactNode;
  className?: string;
  index?: number;
}> = ({ children, className = '', index = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 25, scale: 0.985 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      viewport={{ once: true, margin: '-30px' }}
      transition={{
        duration: 0.6,
        delay: (index % 4) * 0.07,
        ease: slickEase,
      }}
      className={`transform-gpu will-change-transform ${className}`}
    >
      {children}
    </motion.div>
  );
};
