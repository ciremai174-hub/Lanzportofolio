import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Menu, X, ArrowUpRight, RotateCcw } from 'lucide-react';
import { PortfolioData } from '../types';
import { smoothEase } from './motion/MotionText';

interface NavbarProps {
  data: PortfolioData['navigation'];
  onReplayIntro: () => void;
  siteConfig?: PortfolioData['siteConfig'];
}

export const Navbar: React.FC<NavbarProps> = ({ data, onReplayIntro, siteConfig }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      const sections = ['home', 'album', 'skills', 'profile', 'kontak'];
      const scrollPosition = window.scrollY + 160;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const targetId = href.replace('#', '');
    const element = document.getElementById(targetId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <motion.header
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.7, ease: smoothEase }}
      className="sticky top-0 z-40 w-full px-4 sm:px-6 lg:px-8 pt-4 pb-2"
    >
      <div
        className={`max-w-7xl mx-auto bg-white border-3 border-[#09090B] transition-all duration-200 ${
          isScrolled ? 'neo-shadow' : 'neo-shadow-lg'
        } p-3 sm:p-4`}
      >
        <div className="flex items-center justify-between">
          {/* Brand Logo */}
          <a
            href="#home"
            onClick={(e) => scrollToSection(e, '#home')}
            className="group flex items-center gap-2.5 select-none"
          >
            <div className="w-10 h-10 bg-[#2563EB] text-white border-2 border-[#09090B] neo-shadow-sm flex items-center justify-center font-black text-xl font-['Space_Grotesk'] group-hover:translate-x-0.5 group-hover:translate-y-0.5 transition-transform">
              L
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-black tracking-tight text-[#09090B] font-['Space_Grotesk'] flex items-center gap-1">
                <span>{(siteConfig?.pageCopy?.navbarBrand || data.brandName).slice(0, 4)}</span>
                <span className="text-[#2563EB] underline decoration-4 decoration-[#09090B]">
                  {(siteConfig?.pageCopy?.navbarBrand || data.brandName).slice(4)}
                </span>
              </div>
              <p className="text-[10px] font-bold tracking-widest text-zinc-600 uppercase font-mono">
                {siteConfig?.pageCopy?.navbarSubtext || data.brandSubtext}
              </p>
            </div>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {data.menuItems.filter((item) => item.active !== false).map((item, idx) => {
              const isActive = activeSection === item.id;
              return (
                <motion.a
                  key={item.id}
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.15 + idx * 0.05, duration: 0.5, ease: smoothEase }}
                  href={item.href}
                  onClick={(e) => scrollToSection(e, item.href)}
                  className={`px-3 py-1.5 text-xs lg:text-sm font-extrabold uppercase tracking-wide transition-all duration-150 border-2 ${
                    isActive
                      ? 'bg-[#2563EB] text-white border-[#09090B] neo-shadow-sm translate-x-0.5 translate-y-0.5'
                      : 'border-transparent text-[#09090B] hover:border-[#09090B] hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </motion.a>
              );
            })}
          </nav>

          {/* Right Action Buttons (Isolated from public admin access) */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Replay Intro button */}
            <button
              onClick={onReplayIntro}
              title="Putar Ulang Animasi Intro"
              className="p-2 bg-slate-100 hover:bg-slate-200 text-[#09090B] border-2 border-[#09090B] neo-shadow-sm active:translate-x-0.5 active:translate-y-0.5 transition-all text-xs font-bold hidden sm:flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="text-[11px] font-mono">INTRO</span>
            </button>

            {/* Direct Contact CTA */}
            <a
              href="#kontak"
              onClick={(e) => scrollToSection(e, '#kontak')}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 bg-[#09090B] text-white font-bold text-xs lg:text-sm border-2 border-[#09090B] neo-shadow-blue hover:-translate-x-0.5 hover:-translate-y-0.5 active:translate-x-0 transition-transform uppercase"
            >
              <span>Hubungi</span>
              <ArrowUpRight className="w-4 h-4 text-[#2563EB]" />
            </a>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 bg-white text-[#09090B] border-2 border-[#09090B] neo-shadow-sm"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-4 pt-4 border-t-2 border-[#09090B] flex flex-col gap-2">
            {data.menuItems.filter((item) => item.active !== false).map((item) => (
              <a
                key={item.id}
                href={item.href}
                onClick={(e) => scrollToSection(e, item.href)}
                className="px-3 py-2 text-sm font-extrabold text-[#09090B] border-2 border-[#09090B] neo-shadow-sm hover:bg-[#2563EB] hover:text-white transition-colors"
              >
                {item.label}
              </a>
            ))}
            <div className="pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onReplayIntro();
                }}
                className="w-full py-2 bg-slate-100 text-[#09090B] border-2 border-[#09090B] text-xs font-bold neo-shadow-sm flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>ULANG ANIMASI INTRO</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </motion.header>
  );
};
