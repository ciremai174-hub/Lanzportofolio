import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, ArrowRight, Terminal, CheckCircle2, Lock, Sparkles, ExternalLink } from 'lucide-react';
import { PortfolioData } from '../types';
import { smoothEase, StaggerHeading, StaggerParagraph, containerStagger, itemFadeUp } from './motion/MotionText';

interface HeroSectionProps {
  data: PortfolioData['hero'];
  pageCopy?: Record<string, string>;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ data, pageCopy = {} }) => {
  const [terminalTab, setTerminalTab] = useState<'stack' | 'security' | 'status'>('stack');

  return (
    <section id="home" className="relative pt-8 pb-16 sm:py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Text & Badges & CTA */}
          <motion.div
            variants={containerStagger}
            initial="hidden"
            animate="visible"
            className="lg:col-span-7 space-y-6"
          >
            {/* Top Status Pill with Stagger */}
            <motion.div variants={itemFadeUp} className="inline-block">
              <div className="inline-flex items-center gap-2.5 px-3.5 py-1.5 bg-white border-2 border-[#09090B] neo-shadow-sm">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-black uppercase tracking-wider font-mono text-[#09090B]">
                  {data.statusText}
                </span>
              </div>
            </motion.div>

            {/* Greeting & Main Punchy Title with Smooth Staggered Reveal */}
            <motion.div variants={itemFadeUp} className="space-y-2">
              <p className="text-sm sm:text-base font-extrabold uppercase tracking-widest text-[#2563EB] font-mono">
                {data.greeting}
              </p>
              <h1 className="text-4xl sm:text-6xl xl:text-7xl font-black text-[#09090B] tracking-tight leading-[1.06] font-['Space_Grotesk']">
                <StaggerHeading text={data.name} as="span" />{' '}
                <span className="text-[#09090B]">—</span>{' '}
                <br className="hidden sm:inline" />
                <span className="bg-[#2563EB] text-white px-2.5 py-0.5 inline-block border-2 border-[#09090B] neo-shadow-sm mt-1">
                  {pageCopy.heroTitleLead || 'Fullstack & Cyber'}
                </span>{' '}
                <StaggerHeading text={pageCopy.heroTitleEnd || "Architect"} as="span" />
              </h1>
            </motion.div>

            {/* Tagline with Smooth Stagger */}
            <motion.div variants={itemFadeUp}>
              <p className="text-base sm:text-lg font-bold text-slate-800 leading-relaxed border-l-4 border-[#2563EB] pl-4 py-1">
                {data.tagline}
              </p>
            </motion.div>

            {/* Bio Paragraph */}
            <motion.div variants={itemFadeUp}>
              <p className="text-sm sm:text-base text-zinc-600 leading-relaxed font-medium">
                {data.bio}
              </p>
            </motion.div>

            {/* Badges Array Staggered */}
            <motion.div variants={itemFadeUp} className="flex flex-wrap gap-2 pt-1">
              {data.badges.map((badge, idx) => (
                <motion.span
                  key={idx}
                  initial={{ opacity: 0, scale: 0.9, y: 15 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ delay: 0.3 + idx * 0.08, duration: 0.5, ease: smoothEase }}
                  className="px-2.5 py-1 bg-amber-200 text-[#09090B] border-2 border-[#09090B] text-xs font-black neo-shadow-sm uppercase font-mono flex items-center gap-1.5"
                >
                  <Shield className="w-3 h-3 text-[#2563EB]" />
                  {badge}
                </motion.span>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div variants={itemFadeUp} className="flex flex-wrap gap-4 pt-4">
              <a
                href={data.primaryCtaLink}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#2563EB] text-white font-black text-sm uppercase tracking-wide border-3 border-[#09090B] neo-shadow hover:-translate-x-0.5 hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_#09090B] active:translate-x-0 active:translate-y-0 active:shadow-[2px_2px_0px_#09090B] transition-all"
              >
                <span>{data.primaryCtaText}</span>
                <ArrowRight className="w-4 h-4" />
              </a>

              <a
                href={data.secondaryCtaLink}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-white text-[#09090B] font-black text-sm uppercase tracking-wide border-3 border-[#09090B] neo-shadow hover:-translate-x-0.5 hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_#09090B] active:translate-x-0 active:translate-y-0 active:shadow-[2px_2px_0px_#09090B] transition-all"
              >
                <span>{data.secondaryCtaText}</span>
                <ExternalLink className="w-4 h-4 text-zinc-500" />
              </a>
            </motion.div>
          </motion.div>

          {/* Right Column: Neo-Brutalist Avatar Card & Cyber Terminal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25, ease: smoothEase }}
            className="lg:col-span-5 space-y-6"
          >
            {/* Main Avatar Card */}
            <div className="relative bg-white border-3 border-[#09090B] neo-shadow-lg p-4">
              {/* Corner Badge */}
              <div className="absolute -top-3 -right-3 bg-yellow-300 text-[#09090B] border-2 border-[#09090B] neo-shadow-sm px-3 py-1 text-xs font-black uppercase tracking-wider font-mono flex items-center gap-1.5 rotate-2">
                <Sparkles className="w-3.5 h-3.5 text-[#2563EB]" />
                VERIFIED ARCHITECT
              </div>

              {/* Photo Frame */}
              <div className="relative border-2 border-[#09090B] overflow-hidden bg-slate-900 aspect-[4/3] group">
                <img
                  src={data.avatarUrl}
                  alt={data.name}
                  className="w-full h-full object-cover object-center grayscale contrast-125 group-hover:grayscale-0 group-hover:scale-105 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
                  <div className="text-white font-mono text-xs space-y-1">
                    <p className="font-bold flex items-center gap-1.5">
                      <Lock className="w-3.5 h-3.5 text-[#2563EB]" />
                      DEFENSIVE LAYER 7 ACTIVE
                    </p>
                    <p className="text-zinc-300 text-[11px]">
                      Firebase Firestore • Node.js Express Engine
                    </p>
                  </div>
                </div>
              </div>

              {/* Stats Mini Row */}
              <div className="grid grid-cols-3 gap-2 mt-3 pt-3 border-t-2 border-[#09090B] text-center font-mono">
                <div className="bg-slate-50 border-2 border-[#09090B] p-2 neo-shadow-sm">
                  <div className="text-lg font-black text-[#2563EB]">{pageCopy.heroStatOneValue || '100%'}</div>
                  <div className="text-[10px] font-bold text-zinc-600 uppercase">{pageCopy.heroStatOneLabel || 'Resilient'}</div>
                </div>
                <div className="bg-slate-50 border-2 border-[#09090B] p-2 neo-shadow-sm">
                  <div className="text-lg font-black text-[#09090B]">{pageCopy.heroStatTwoValue || 'MERN'}</div>
                  <div className="text-[10px] font-bold text-zinc-600 uppercase">{pageCopy.heroStatTwoLabel || 'Core Stack'}</div>
                </div>
                <div className="bg-slate-50 border-2 border-[#09090B] p-2 neo-shadow-sm">
                  <div className="text-lg font-black text-emerald-600">{pageCopy.heroStatThreeValue || 'JWT+AES'}</div>
                  <div className="text-[10px] font-bold text-zinc-600 uppercase">{pageCopy.heroStatThreeLabel || 'Protected'}</div>
                </div>
              </div>
            </div>

            {/* Interactive Cyber Terminal Window */}
            <div className="bg-[#09090B] text-white border-3 border-[#09090B] neo-shadow-blue p-4 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-zinc-800 pb-2 mb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-[#2563EB]" />
                  <span className="font-bold text-zinc-300">lanz-shell@root:~#</span>
                </div>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setTerminalTab('stack')}
                    className={`px-2 py-0.5 text-[10px] font-bold border transition-colors ${
                      terminalTab === 'stack' ? 'bg-[#2563EB] text-white border-white' : 'border-zinc-700 text-zinc-400'
                    }`}
                  >
                    STACK
                  </button>
                  <button
                    onClick={() => setTerminalTab('security')}
                    className={`px-2 py-0.5 text-[10px] font-bold border transition-colors ${
                      terminalTab === 'security' ? 'bg-[#2563EB] text-white border-white' : 'border-zinc-700 text-zinc-400'
                    }`}
                  >
                    SECURITY
                  </button>
                  <button
                    onClick={() => setTerminalTab('status')}
                    className={`px-2 py-0.5 text-[10px] font-bold border transition-colors ${
                      terminalTab === 'status' ? 'bg-[#2563EB] text-white border-white' : 'border-zinc-700 text-zinc-400'
                    }`}
                  >
                    DB STATUS
                  </button>
                </div>
              </div>

              {terminalTab === 'stack' && (
                <div className="space-y-1 text-zinc-300 leading-relaxed">
                  <p className="text-emerald-400">$ cat /etc/runtime-profile.env</p>
                  <p>FRAMEWORK: Next.js / React 19 + TypeScript</p>
                  <p>DATABASE: Google Firebase Cloud Firestore</p>
                  <p>STYLING: Neo-Brutalism Tailwind CSS System</p>
                  <p>ANIMATION: Framer Motion Hardware-Accelerated</p>
                </div>
              )}

              {terminalTab === 'security' && (
                <div className="space-y-1 text-zinc-300 leading-relaxed">
                  <p className="text-emerald-400">$ ./verify-cyber-defense.sh</p>
                  <p className="flex items-center gap-1.5 text-zinc-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Helmet.js HTTP Headers Hardening [ACTIVE]
                  </p>
                  <p className="flex items-center gap-1.5 text-zinc-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Express Rate Limiter Anti-DDoS [10 req/15m]
                  </p>
                  <p className="flex items-center gap-1.5 text-zinc-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    Bcrypt Hash (Salt=10) + JWT Bearer Auth [PASS]
                  </p>
                </div>
              )}

              {terminalTab === 'status' && (
                <div className="space-y-1 text-zinc-300 leading-relaxed">
                  <p className="text-emerald-400">$ firebase-admin --status</p>
                  <p>STORAGE_ENGINE: Cloud Firestore Real-time Sync</p>
                  <p>SECURITY: Zero-Trust Firebase Rules RBAC</p>
                  <p>AUTH_ENGINE: Firebase Authentication (OAuth & Email)</p>
                  <p className="text-blue-400">LATENCY: &lt; 2ms (Direct Engine)</p>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
