import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Lock,
  User,
  Shield,
  Database,
  Layers,
  Image as ImageIcon,
  Cpu,
  Mail,
  UserPlus,
  Save,
  RotateCcw,
  LogOut,
  X,
  Plus,
  Trash2,
  Edit,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  KeyRound,
  Eye,
  EyeOff,
  Sparkles,
  Server,
  RefreshCw,
  Share2,
  Globe,
  ArrowLeft,
} from 'lucide-react';
import { PortfolioData, AdminUser, ContactMessage, DatabaseStatus } from '../../types';
import { firestoreService } from '../../services/firestoreService';
import { smoothEase } from '../motion/MotionText';
import { SocialIcon } from '../common/SocialIcon';
import { initialPortfolioData } from '../../../server/defaultData';

interface AdminPortalProps {
  portfolioData: PortfolioData;
  onUpdatePortfolio: (newData: PortfolioData) => void;
  onClose: () => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  portfolioData,
  onUpdatePortfolio,
  onClose,
}) => {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser | null>(null);
  const [tokenLoading, setTokenLoading] = useState<boolean>(true);

  // Login form state
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  // Active Tab
  type TabType = 'overview' | 'site' | 'hero' | 'navigation' | 'socials' | 'album' | 'skills' | 'profile' | 'messages' | 'admins';
  const [activeTab, setActiveTab] = useState<TabType>('overview');

  // Working copy of portfolio for editing
  const [draft, setDraft] = useState<PortfolioData>(JSON.parse(JSON.stringify(portfolioData)));
  const [isDirty, setIsDirty] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState<string | null>(null);
  // Advanced full-content editor: exposes every persisted field, including text not covered by individual forms.
  const [jsonEditorText, setJsonEditorText] = useState(() => JSON.stringify(portfolioData, null, 2));
  const [jsonEditorFeedback, setJsonEditorFeedback] = useState<string | null>(null);
  const [siteToolFeedback, setSiteToolFeedback] = useState<string | null>(null);
  const [revisionHistory, setRevisionHistory] = useState<Array<{ at: string; by: string; snapshot: string }>>([]);
  const [activityHistory, setActivityHistory] = useState<Array<{ at: string; by: string; action: string }>>([]);
  const [previewWidth, setPreviewWidth] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');

  // Messages state
  const [messages, setMessages] = useState<ContactMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);

  // Admin users state
  const [adminsList, setAdminsList] = useState<AdminUser[]>([]);
  const [newAdminUser, setNewAdminUser] = useState('');
  const [newAdminRole, setNewAdminRole] = useState<'admin' | 'superadmin'>('admin');
  const [createAdminMsg, setCreateAdminMsg] = useState<{ text: string; error?: boolean } | null>(null);

  // DB Status
  const [dbStatus, setDbStatus] = useState<DatabaseStatus | null>(null);

  // Keep the editable draft and the advanced JSON editor synchronized.
  useEffect(() => {
    const copy = JSON.parse(JSON.stringify(portfolioData));
    if (!copy.socialLinks) copy.socialLinks = initialPortfolioData.socialLinks;
    setDraft(copy);
    setJsonEditorText(JSON.stringify(copy, null, 2));
  }, [portfolioData]);

  useEffect(() => {
    setJsonEditorText(JSON.stringify(draft, null, 2));
  }, [draft]);

  // Local admin audit/history snapshots for quick recovery in the same browser.
  useEffect(() => {
    try {
      setRevisionHistory(JSON.parse(localStorage.getItem('lanz-cms-revisions') || '[]'));
      setActivityHistory(JSON.parse(localStorage.getItem('lanz-cms-activity') || '[]'));
    } catch { /* Ignore corrupted local history and continue normally. */ }
  }, []);

  const recordActivity = (action: string) => {
    const entry = { at: new Date().toISOString(), by: currentAdmin?.username || 'Admin', action };
    const next = [entry, ...activityHistory].slice(0, 50);
    setActivityHistory(next);
    try { localStorage.setItem('lanz-cms-activity', JSON.stringify(next)); } catch { /* storage may be unavailable */ }
  };

  const saveLocalDraft = () => {
    try {
      localStorage.setItem('lanz-cms-draft', JSON.stringify(draft));
      setSiteToolFeedback('Draft disimpan di browser ini. Belum dipublikasikan ke website.');
      recordActivity('Menyimpan draft lokal');
    } catch { setSiteToolFeedback('Gagal menyimpan draft lokal. Periksa ruang penyimpanan browser.'); }
  };

  const restoreLocalDraft = () => {
    try {
      const saved = localStorage.getItem('lanz-cms-draft');
      if (!saved) { setSiteToolFeedback('Belum ada draft lokal yang tersimpan di browser ini.'); return; }
      const parsed = JSON.parse(saved);
      if (!parsed?.hero || !parsed?.siteConfig || !Array.isArray(parsed?.album)) throw new Error('Struktur draft tidak valid.');
      setDraft(parsed as PortfolioData); setIsDirty(true);
      setSiteToolFeedback('Draft dipulihkan ke editor. Tekan Publish / Simpan ke Firestore untuk menerapkan.');
      recordActivity('Memulihkan draft lokal');
    } catch { setSiteToolFeedback('Draft lokal tidak valid atau tidak bisa dibaca.'); }
  };

  // Firebase Auth state listener
  useEffect(() => {
    const unsub = firestoreService.onAuthState(async (user) => {
      if (user) {
        const authorized = await firestoreService.isAuthorizedAdmin(user.email);
        if (!authorized) {
          await firestoreService.logout();
          setIsAuthenticated(false);
          setCurrentAdmin(null);
          setLoginError('Akun ini belum terdaftar sebagai administrator. Hubungi pemilik website.');
        } else {
          setIsAuthenticated(true);
          setCurrentAdmin({
            id: user.uid,
            username: user.email || user.displayName || 'Admin',
            role: 'admin',
          });
          setDbStatus({
            database: 'Google Firebase Cloud Firestore & Auth',
            isFirebaseConnected: true,
            provider: 'Cloud Firestore Native Client SDK',
            error: null,
          });
        }
      } else {
        setIsAuthenticated(false);
        setCurrentAdmin(null);
      }
      setTokenLoading(false);
    });
    return () => unsub();
  }, []);

  // Fetch messages and admins when tab changes
  useEffect(() => {
    if (!isAuthenticated) return;

    if (activeTab === 'messages' || activeTab === 'overview') {
      loadMessages();
    }
    if (activeTab === 'admins') {
      loadAdmins();
    }
  }, [activeTab, isAuthenticated]);

  const loadMessages = async () => {
    setMessagesLoading(true);
    try {
      const data = await firestoreService.getMessages();
      setMessages(data);
    } catch (err: any) {
      console.error(err);
    } finally {
      setMessagesLoading(false);
    }
  };

  const loadAdmins = async () => {
    try {
      const users = await firestoreService.getAdmins();
      setAdminsList(users);
    } catch (err: any) {
      console.error(err);
    }
  };

  const handleGoogleLogin = async () => {
    setLoginError(null);
    setLoginLoading(true);
    try {
      const user = await firestoreService.signInWithGoogle();
      if (!(await firestoreService.isAuthorizedAdmin(user.email))) {
        await firestoreService.logout();
        throw new Error('Akun ini belum terdaftar sebagai administrator. Hubungi pemilik website.');
      }
      setIsAuthenticated(true);
      setCurrentAdmin({
        id: user.uid,
        username: user.email || user.displayName || 'Admin',
        role: 'admin',
      });
    } catch (err: any) {
      setLoginError(err.message || 'Gagal masuk dengan akun Google.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoginLoading(true);

    try {
      const user = await firestoreService.signInWithEmail(usernameInput, passwordInput);
      if (!(await firestoreService.isAuthorizedAdmin(user.email))) {
        await firestoreService.logout();
        throw new Error('Akun ini belum terdaftar sebagai administrator. Hubungi pemilik website.');
      }
      setIsAuthenticated(true);
      setCurrentAdmin({
        id: user.uid,
        username: user.email || user.displayName || 'Admin',
        role: 'admin',
      });
      setUsernameInput('');
      setPasswordInput('');
    } catch (err: any) {
      setLoginError(err.message || 'Login gagal. Pastikan akun sudah dibuat di Firebase Authentication.');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await firestoreService.logout();
    } catch (err) {
      console.warn(err);
    }
    setIsAuthenticated(false);
    setCurrentAdmin(null);
    onClose();
  };

  const handleSaveToFirestore = async () => {
    setSaveLoading(true);
    setSaveFeedback(null);
    try {
      const snapshot = { at: new Date().toISOString(), by: currentAdmin?.username || 'Admin', snapshot: JSON.stringify(draft) };
      const nextRevisions = [snapshot, ...revisionHistory].slice(0, 10);
      try { localStorage.setItem('lanz-cms-revisions', JSON.stringify(nextRevisions)); } catch { /* revision history is best-effort */ }
      setRevisionHistory(nextRevisions);
      await firestoreService.savePortfolioData(draft);
      onUpdatePortfolio(draft);
      setIsDirty(false);
      recordActivity('Publish perubahan ke Firestore');
      setSaveFeedback('Berhasil dipublikasikan ke Firebase Firestore.');
      setTimeout(() => setSaveFeedback(null), 4000);
    } catch (err: any) {
      setSaveFeedback('Gagal menyimpan ke Firestore: ' + err.message);
    } finally {
      setSaveLoading(false);
    }
  };

  const handleResetDefaults = async () => {
    if (!window.confirm('Yakin ingin mereset seluruh konten portofolio ke nilai default pabrikan?')) {
      return;
    }
    setSaveLoading(true);
    try {
      await firestoreService.savePortfolioData(initialPortfolioData);
      setDraft(initialPortfolioData);
      onUpdatePortfolio(initialPortfolioData);
      setIsDirty(false);
      alert('Konten berhasil direset dan disimpan ke Firebase Firestore!');
    } catch (err: any) {
      alert('Gagal mereset: ' + err.message);
    } finally {
      setSaveLoading(false);
    }
  };

  const handleCreateNewAdmin = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateAdminMsg(null);
    const email = newAdminUser.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setCreateAdminMsg({ text: 'Masukkan alamat email yang valid.', error: true });
      return;
    }
    try {
      // This action authorizes an existing Firebase Authentication account; it does not create a login/password.
      await firestoreService.addAdmin(email, newAdminRole);
      setCreateAdminMsg({ text: `Akun ${email} diberi akses ${newAdminRole}. Pastikan akun ini sudah dibuat di Firebase Authentication.` });
      setNewAdminUser('');
      await loadAdmins();
    } catch (err: any) {
      setCreateAdminMsg({ text: err.message || 'Gagal mendaftarkan akses admin.', error: true });
    }
  };

  const handleDeleteAdmin = async (id: string, name: string) => {
    if (!window.confirm(`Hapus akun admin '${name}' dari Firebase?`)) return;
    try {
      await firestoreService.deleteAdmin(id);
      loadAdmins();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleToggleMessageStatus = async (id: string, current: string) => {
    const nextStatus = current === 'unread' ? 'read' : 'unread';
    try {
      await firestoreService.updateMessageStatus(id, nextStatus as any);
      loadMessages();
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDeleteMessage = async (id: string) => {
    if (!window.confirm('Hapus pesan ini dari Firebase Firestore?')) return;
    try {
      await firestoreService.deleteMessage(id);
      loadMessages();
    } catch (err: any) {
      alert(err.message);
    }
  };

  // Helper updater for draft
  const updateDraft = (updater: (prev: PortfolioData) => PortfolioData) => {
    setDraft((prev) => {
      const next = updater(prev);
      setIsDirty(true);
      return next;
    });
  };

  if (tokenLoading) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 font-mono text-white">
        <div className="bg-[#09090B] border-3 border-white p-6 neo-shadow flex items-center gap-3">
          <RefreshCw className="w-5 h-5 animate-spin text-[#2563EB]" />
          <span>MEMVERIFIKASI TOKEN AKSES ADMIN...</span>
        </div>
      </div>
    );
  }

  // --- UN-AUTHENTICATED: PRIVATE ADMIN LOGIN PAGE ---
  if (!isAuthenticated) {
    return (
      <div className="relative flex min-h-screen w-full items-center justify-center overflow-hidden bg-[#f5f7fb] px-4 py-6 font-sans text-slate-900 sm:px-6">
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-blue-100 via-[#f5f7fb] to-white" />
        <div className="pointer-events-none absolute -right-24 top-16 h-72 w-72 rounded-full bg-blue-200/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -left-20 h-72 w-72 rounded-full bg-indigo-200/40 blur-3xl" />

        <div className="relative z-10 grid w-full max-w-5xl overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-[0_28px_90px_-35px_rgba(15,23,42,0.28)] md:grid-cols-[0.92fr_1.08fr]">
          <aside className="relative hidden flex-col justify-between overflow-hidden bg-[#101d3b] p-10 text-white md:flex lg:p-12">
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full border border-white/10" />
            <div className="absolute -right-10 -top-10 h-44 w-44 rounded-full border border-white/10" />
            <div className="absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-blue-500/20 blur-2xl" />
            <div className="relative flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-500 text-lg font-black shadow-lg shadow-blue-950/30">L</div>
              <div>
                <div className="text-lg font-extrabold tracking-tight">Lanz<span className="text-blue-300">Portofolio</span></div>
                <div className="mt-0.5 text-[10px] font-semibold uppercase tracking-[0.22em] text-blue-200/70">Content management</div>
              </div>
            </div>
            <div className="relative my-12">
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-blue-300/20 bg-white/5 px-3 py-1.5 text-[11px] font-semibold tracking-wide text-blue-100">
                <Shield className="h-3.5 w-3.5" /> PRIVATE ADMIN AREA
              </div>
              <h1 className="max-w-sm text-4xl font-bold leading-[1.12] tracking-tight lg:text-[42px]">Kelola portofolio, <span className="text-blue-300">dengan aman.</span></h1>
              <p className="mt-5 max-w-sm text-sm leading-7 text-slate-300">Satu tempat untuk memperbarui konten, galeri, keahlian, dan informasi website kamu.</p>
              <div className="mt-8 space-y-3 text-sm text-slate-300">
                <div className="flex items-center gap-3"><CheckCircle className="h-4 w-4 text-emerald-300" /> Pengelolaan konten terpusat</div>
                <div className="flex items-center gap-3"><CheckCircle className="h-4 w-4 text-emerald-300" /> Sinkronisasi melalui Firebase</div>
                <div className="flex items-center gap-3"><CheckCircle className="h-4 w-4 text-emerald-300" /> Akses berdasarkan autentikasi</div>
              </div>
            </div>
            <div className="relative flex items-center justify-between border-t border-white/10 pt-5 text-[11px] text-slate-400">
              <span>LANZPORTOFOLIO</span><span>ADMIN CONSOLE</span>
            </div>
          </aside>

          <main className="flex items-center justify-center p-6 sm:p-10 lg:p-14">
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: smoothEase }}
              className="w-full max-w-md"
            >
              <button type="button" onClick={onClose} className="mb-8 inline-flex items-center gap-2 text-xs font-semibold text-slate-500 transition hover:text-blue-700">
                <ArrowLeft className="h-4 w-4" /> Kembali ke halaman publik
              </button>
              <div className="mb-8">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-700 ring-1 ring-blue-100"><Lock className="h-5 w-5" /></div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-blue-700">Admin sign in</p>
                <h2 className="mt-2 text-3xl font-bold tracking-tight text-slate-950">Selamat datang</h2>
                <p className="mt-2 text-sm leading-6 text-slate-500">Masuk menggunakan akun administrator yang sudah terdaftar.</p>
              </div>

              {loginError && (
                <div role="alert" className="mb-5 flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 p-3.5 text-sm text-red-800">
                  <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{loginError}</span>
                </div>
              )}

              <button
                type="button"
                onClick={handleGoogleLogin}
                disabled={loginLoading}
                className="flex w-full items-center justify-center gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:border-slate-300 hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <svg className="h-5 w-5" viewBox="0 0 24 24" aria-hidden="true">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 1 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                {loginLoading ? 'Menghubungkan...' : 'Lanjutkan dengan Google'}
              </button>

              <div className="my-6 flex items-center gap-3"><div className="h-px flex-1 bg-slate-200" /><span className="text-[11px] font-medium uppercase tracking-wider text-slate-400">atau gunakan email</span><div className="h-px flex-1 bg-slate-200" /></div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-1.5">
                  <label htmlFor="admin-email" className="block text-xs font-semibold text-slate-700">Email administrator</label>
                  <div className="relative">
                    <input id="admin-email" type="email" autoComplete="username" required value={usernameInput} onChange={(e) => setUsernameInput(e.target.value)} placeholder="nama@domain.com" className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-11 text-sm outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10" />
                    <User className="absolute right-3.5 top-3.5 h-4 w-4 text-slate-400" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label htmlFor="admin-password" className="block text-xs font-semibold text-slate-700">Password</label>
                  <div className="relative">
                    <input id="admin-password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" required value={passwordInput} onChange={(e) => setPasswordInput(e.target.value)} placeholder="Masukkan password" className="w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 pr-12 text-sm outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:ring-4 focus:ring-blue-500/10" />
                    <button type="button" aria-label={showPassword ? 'Sembunyikan password' : 'Tampilkan password'} onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-3.5 text-slate-400 transition hover:text-slate-700">{showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</button>
                  </div>
                </div>
                <button type="submit" disabled={loginLoading} className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3.5 text-sm font-semibold text-white shadow-lg shadow-blue-600/20 transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-50">
                  <KeyRound className="h-4 w-4" />{loginLoading ? 'Memverifikasi akun...' : 'Masuk ke dashboard'}
                </button>
              </form>

              <div className="mt-7 flex items-start gap-2 rounded-xl bg-slate-50 p-3.5 text-xs leading-5 text-slate-500"><Shield className="mt-0.5 h-4 w-4 shrink-0 text-slate-400" /><span>Akses hanya diberikan kepada akun yang sudah diotorisasi. Email akun tidak ditampilkan di halaman login publik.</span></div>
              <div className="mt-6 flex items-center justify-between border-t border-slate-100 pt-5 text-[11px] text-slate-400"><span>Protected admin access</span><span>Firebase Auth</span></div>
            </motion.div>
          </main>
        </div>
      </div>
    );
  }

  // --- AUTHENTICATED: FULL DYNAMIC CMS DASHBOARD ---
  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#F8FAFC] font-sans overflow-hidden">
      
      {/* Top Banner */}
      <header className="bg-[#09090B] text-white border-b-3 border-[#09090B] px-4 sm:px-6 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-[#2563EB] text-white border-2 border-white flex items-center justify-center font-black text-sm font-['Space_Grotesk']">
            L
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm sm:text-base font-['Space_Grotesk']">
                LanzPortofolio CMS
              </span>
              <span className="px-2 py-0.5 bg-emerald-500 text-black text-[10px] font-mono font-black border border-white">
                FIREBASE FIRESTORE & AUTH
              </span>
            </div>
            <p className="text-[10px] font-mono text-zinc-400">
              Logged in: <span className="text-white font-bold">{currentAdmin?.username}</span> ({currentAdmin?.role})
            </p>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3">
          {isDirty && (
            <span className="text-xs font-mono text-amber-400 animate-pulse font-bold hidden sm:inline">
              ● Ada Perubahan Belum Disimpan
            </span>
          )}

          <button
            onClick={handleSaveToFirestore}
            disabled={saveLoading}
            className="px-4 py-2 bg-[#2563EB] text-white border-2 border-white font-mono text-xs font-bold neo-shadow-sm hover:bg-blue-600 transition-colors flex items-center gap-1.5"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{saveLoading ? 'MENYIMPAN...' : 'SIMPAN KE FIRESTORE'}</span>
          </button>

          <button
            onClick={handleLogout}
            title="Keluar dari Panel Admin"
            className="p-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white border border-zinc-600"
          >
            <LogOut className="w-4 h-4" />
          </button>

          <button
            onClick={onClose}
            title="Kembali ke Beranda Publik"
            className="px-3.5 py-2 bg-white text-[#09090B] hover:bg-slate-200 border-2 border-white font-black text-xs font-mono flex items-center gap-1.5 transition-colors neo-shadow-sm"
          >
            <ArrowLeft className="w-4 h-4 text-[#2563EB]" />
            <span className="hidden sm:inline">KEMBALI KE HALAMAN PUBLIK</span>
          </button>
        </div>
      </header>

      {/* Save Feedback Alert */}
      {saveFeedback && (
        <div className="bg-emerald-600 text-white px-4 py-2 text-xs font-mono font-bold flex items-center justify-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>{saveFeedback}</span>
        </div>
      )}

      {/* Main Container */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        
        {/* Sidebar Nav */}
        <nav className="w-full md:w-64 bg-white border-r-3 border-b-3 md:border-b-0 border-[#09090B] p-3 sm:p-4 overflow-x-auto md:overflow-y-auto flex md:flex-col gap-1.5 shrink-0">
          {[
            { id: 'overview', label: 'Ringkasan Sistem', icon: Database },
            { id: 'site', label: 'FULL ACCESS ADMIN • ALL CONTENT', icon: Globe },
            { id: 'hero', label: 'Hero & Identitas', icon: Layers },
            { id: 'navigation', label: 'Menu & Navigasi', icon: Server },
            { id: 'socials', label: 'Media Sosial Resmi', icon: Share2 },
            { id: 'album', label: 'Album & Galeri', icon: ImageIcon },
            { id: 'skills', label: 'Keahlian (Skills)', icon: Cpu },
            { id: 'profile', label: 'Profil & Visi IT', icon: User },
            { id: 'messages', label: `Pesan Masuk (${messages.filter((m) => m.status === 'unread').length})`, icon: Mail },
            { id: 'admins', label: 'Kelola Admin Baru', icon: UserPlus },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`p-2.5 text-xs font-mono font-bold uppercase tracking-wider text-left border-2 transition-all flex items-center gap-2.5 whitespace-nowrap ${
                  isActive
                    ? 'bg-[#2563EB] text-white border-[#09090B] neo-shadow-sm'
                    : 'bg-white text-[#09090B] border-transparent hover:border-[#09090B] hover:bg-slate-100'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}

          <div className="hidden md:block pt-4 mt-auto border-t-2 border-slate-200">
            <button
              onClick={handleResetDefaults}
              className="w-full py-2 bg-slate-100 hover:bg-red-100 text-zinc-700 hover:text-red-700 border-2 border-[#09090B] text-xs font-mono font-bold flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Data Default</span>
            </button>
          </div>
        </nav>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6 max-w-5xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Ringkasan Ekosistem LanzPortofolio
                </h2>
                <p className="text-zinc-600 text-sm mt-1">
                  Status arsitektur server, basis data Firebase Cloud Firestore, dan statistik konten real-time.
                </p>
              </div>

              {/* Stat Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white border-3 border-[#09090B] p-5 neo-shadow">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-xs font-bold">
                    <span>ALBUM PROYEK</span>
                    <ImageIcon className="w-4 h-4 text-[#2563EB]" />
                  </div>
                  <div className="text-3xl font-black text-[#09090B] mt-2 font-['Space_Grotesk']">
                    {draft.album.length}
                  </div>
                  <p className="text-xs text-zinc-500 mt-1 font-mono">Item Galeri Aktif</p>
                </div>

                <div className="bg-white border-3 border-[#09090B] p-5 neo-shadow">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-xs font-bold">
                    <span>KATEGORI SKILL</span>
                    <Cpu className="w-4 h-4 text-[#2563EB]" />
                  </div>
                  <div className="text-3xl font-black text-[#09090B] mt-2 font-['Space_Grotesk']">
                    {draft.skills.length}
                  </div>
                  <p className="text-xs text-zinc-500 mt-1 font-mono">
                    {draft.skills.reduce((acc, c) => acc + c.items.length, 0)} Total Teknologi
                  </p>
                </div>

                <div className="bg-white border-3 border-[#09090B] p-5 neo-shadow">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-xs font-bold">
                    <span>PESAN MASUK</span>
                    <Mail className="w-4 h-4 text-[#2563EB]" />
                  </div>
                  <div className="text-3xl font-black text-[#09090B] mt-2 font-['Space_Grotesk']">
                    {messages.length}
                  </div>
                  <p className="text-xs text-emerald-600 font-bold mt-1 font-mono">
                    {messages.filter((m) => m.status === 'unread').length} Belum Dibaca
                  </p>
                </div>

                <div className="bg-white border-3 border-[#09090B] p-5 neo-shadow">
                  <div className="flex items-center justify-between text-zinc-500 font-mono text-xs font-bold">
                    <span>STATUS SIBER</span>
                    <Shield className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div className="text-lg font-black text-emerald-600 mt-2 font-mono">
                    100% SECURE
                  </div>
                  <p className="text-xs text-zinc-500 mt-1 font-mono">Helmet + Rate-Limit Active</p>
                </div>
              </div>

              {/* DB Status Box */}
              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow space-y-3">
                <div className="flex items-center gap-2 font-mono text-xs font-bold uppercase text-[#2563EB]">
                  <Database className="w-4 h-4" />
                  <span>KONEKSI DATABASE FIREBASE FIRESTORE & AUTH</span>
                </div>
                <div className="p-3 bg-slate-50 border-2 border-[#09090B] font-mono text-xs space-y-1">
                  <p className="font-bold text-[#09090B]">
                    Status: <span className="text-emerald-600">Cloud Firestore & Firebase Auth Online (Real-Time)</span>
                  </p>
                  <p className="text-zinc-600">
                    Koleksi: settings/portfolio, projects, skills, socials, messages, admins dengan Zero-Trust Security Rules.
                  </p>
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow">
                <h3 className="font-black text-base font-['Space_Grotesk'] mb-3">
                  Panduan CMS Dinamis
                </h3>
                <p className="text-xs text-zinc-600 leading-relaxed mb-4">
                  Anda dapat mengubah seluruh teks, foto profil, proyek di galeri, hingga menambahkan akun admin baru tanpa perlu menyentuh kode. Klik tombol <strong>"SIMPAN KE FIRESTORE"</strong> di kanan atas setelah melakukan perubahan.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setActiveTab('hero')}
                    className="px-3 py-1.5 bg-[#2563EB] text-white border-2 border-[#09090B] text-xs font-mono font-bold"
                  >
                    Edit Teks Hero &rarr;
                  </button>
                  <button
                    onClick={() => setActiveTab('album')}
                    className="px-3 py-1.5 bg-yellow-300 text-[#09090B] border-2 border-[#09090B] text-xs font-mono font-bold"
                  >
                    Kelola Album Foto &rarr;
                  </button>
                  <button
                    onClick={() => setActiveTab('admins')}
                    className="px-3 py-1.5 bg-[#09090B] text-white border-2 border-[#09090B] text-xs font-mono font-bold"
                  >
                    Tambah Admin Baru &rarr;
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: HERO & IDENTITAS */}
          {activeTab === 'hero' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Edit Hero Section & Identitas Utama
                </h2>
                <p className="text-zinc-600 text-sm mt-1">
                  Ubah teks sambutan, judul besar, tagline, foto avatar, dan tombol aksi.
                </p>
              </div>

              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Teks Salam (Greeting)
                    </label>
                    <input
                      type="text"
                      value={draft.hero.greeting}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          hero: { ...prev.hero, greeting: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Nama Panggilan / Brand
                    </label>
                    <input
                      type="text"
                      value={draft.hero.name}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          hero: { ...prev.hero, name: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Judul Utama / Peran
                  </label>
                  <input
                    type="text"
                    value={draft.hero.title}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        hero: { ...prev.hero, title: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Tagline Tegas
                  </label>
                  <input
                    type="text"
                    value={draft.hero.tagline}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        hero: { ...prev.hero, tagline: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Bio Singkat
                  </label>
                  <textarea
                    rows={3}
                    value={draft.hero.bio}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        hero: { ...prev.hero, bio: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    URL Foto Profil / Avatar Utama
                  </label>
                  <input
                    type="text"
                    value={draft.hero.avatarUrl}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        hero: { ...prev.hero, avatarUrl: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm font-mono"
                  />
                  <div className="mt-2 flex items-center gap-3">
                    <img
                      src={draft.hero.avatarUrl}
                      alt="Preview"
                      className="w-12 h-12 border-2 border-[#09090B] object-cover"
                    />
                    <span className="text-xs font-mono text-zinc-500">Pratinjau Avatar Langsung</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Teks Tombol Utama
                    </label>
                    <input
                      type="text"
                      value={draft.hero.primaryCtaText}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          hero: { ...prev.hero, primaryCtaText: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Teks Tombol Sekunder
                    </label>
                    <input
                      type="text"
                      value={draft.hero.secondaryCtaText}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          hero: { ...prev.hero, secondaryCtaText: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Teks Status Ketersediaan
                  </label>
                  <input
                    type="text"
                    value={draft.hero.statusText}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        hero: { ...prev.hero, statusText: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm font-mono"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: MENU & NAVIGASI */}
          {activeTab === 'navigation' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Edit Navigasi & Label Menu
                </h2>
                <p className="text-zinc-600 text-sm mt-1">
                  Atur nama brand di logo, subjudul navigasi, dan label menu tautan.
                </p>
              </div>

              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Nama Brand Logo
                    </label>
                    <input
                      type="text"
                      value={draft.navigation.brandName}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          navigation: { ...prev.navigation, brandName: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Subteks Brand
                    </label>
                    <input
                      type="text"
                      value={draft.navigation.brandSubtext}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          navigation: { ...prev.navigation, brandSubtext: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm font-mono"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t-2 border-slate-200">
                  <h4 className="text-sm font-mono font-bold uppercase mb-3 text-[#09090B]">
                    Daftar Menu Navigasi:
                  </h4>
                  <div className="space-y-3">
                    {draft.navigation.menuItems.map((item, idx) => (
                      <div
                        key={item.id}
                        className="p-3 bg-slate-50 border-2 border-[#09090B] flex flex-col sm:flex-row items-center gap-3"
                      >
                        <span className="font-mono text-xs text-zinc-500 w-16">
                          ID: {item.id}
                        </span>
                        <input
                          type="text"
                          value={item.label}
                          onChange={(e) => {
                            const newLabel = e.target.value;
                            updateDraft((prev) => {
                              const updatedItems = [...prev.navigation.menuItems];
                              updatedItems[idx].label = newLabel;
                              return {
                                ...prev,
                                navigation: { ...prev.navigation, menuItems: updatedItems },
                              };
                            });
                          }}
                          className="flex-1 px-3 py-1.5 bg-white border border-[#09090B] text-sm font-bold"
                        />
                        <span className="font-mono text-xs text-zinc-600 bg-zinc-200 px-2 py-1">
                          Anchor: {item.href}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer & Informasi Situs (Full Access) */}
                <div className="pt-6 border-t-2 border-slate-200 space-y-4">
                  <h4 className="text-sm font-mono font-bold uppercase text-[#09090B]">
                    Teks Footer & Informasi Kontak Global:
                  </h4>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Teks Slogan / Deskripsi Footer
                    </label>
                    <textarea
                      rows={2}
                      value={draft.siteConfig.footerText}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          siteConfig: { ...prev.siteConfig, footerText: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase mb-1">
                        Tahun Hak Cipta
                      </label>
                      <input
                        type="text"
                        value={draft.siteConfig.copyrightYear}
                        onChange={(e) =>
                          updateDraft((prev) => ({
                            ...prev,
                            siteConfig: { ...prev.siteConfig, copyrightYear: e.target.value },
                          }))
                        }
                        className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-bold uppercase mb-1">
                        Email Kontak
                      </label>
                      <input
                        type="email"
                        value={draft.siteConfig.contactEmail}
                        onChange={(e) =>
                          updateDraft((prev) => ({
                            ...prev,
                            siteConfig: { ...prev.siteConfig, contactEmail: e.target.value },
                          }))
                        }
                        className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-bold uppercase mb-1">
                        Nomor Telepon
                      </label>
                      <input
                        type="text"
                        value={draft.siteConfig.contactPhone}
                        onChange={(e) =>
                          updateDraft((prev) => ({
                            ...prev,
                            siteConfig: { ...prev.siteConfig, contactPhone: e.target.value },
                          }))
                        }
                        className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-mono font-bold uppercase mb-1">
                      Lokasi Basis
                    </label>
                    <input
                      type="text"
                      value={draft.siteConfig.location}
                      onChange={(e) =>
                        updateDraft((prev) => ({
                          ...prev,
                          siteConfig: { ...prev.siteConfig, location: e.target.value },
                        }))
                      }
                      className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3.5: MEDIA SOSIAL RESMI (FULL ACCESS & OFFICIAL ICONS) */}
          {activeTab === 'socials' && (
            <div className="space-y-6 max-w-5xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#2563EB] text-white border-2 border-[#09090B] neo-shadow-sm text-xs font-mono font-bold uppercase mb-2">
                    <Share2 className="w-3.5 h-3.5" />
                    <span>MANAJEMEN MEDIA SOSIAL RESMI</span>
                  </div>
                  <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                    Tautan Media Sosial & Jejaring
                  </h2>
                  <p className="text-zinc-600 text-sm mt-1">
                    Kelola seluruh akun media sosial dengan logo SVG resmi (Lucide/SVG murni, tanpa emoji).
                  </p>
                </div>

                <button
                  onClick={() => {
                    const newSocial = {
                      id: 'soc-' + Date.now(),
                      platform: 'website' as const,
                      label: 'Tautan Baru',
                      url: 'https://',
                      active: true,
                    };
                    updateDraft((prev) => ({
                      ...prev,
                      socialLinks: [...(prev.socialLinks || []), newSocial],
                    }));
                  }}
                  className="px-4 py-2.5 bg-[#2563EB] text-white border-2 border-[#09090B] font-mono text-xs font-bold neo-shadow-sm flex items-center gap-1.5 hover:bg-blue-600 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>TAMBAH MEDIA SOSIAL BARU</span>
                </button>
              </div>

              {/* Notice Box */}
              <div className="p-4 bg-amber-50 border-2 border-[#09090B] neo-shadow-sm text-xs font-mono space-y-1">
                <p className="font-bold text-[#09090B]">
                  Standar Visual Resmi:
                </p>
                <p className="text-zinc-700">
                  Seluruh ikon menggunakan format vector SVG resmi (Lucide Icons) dengan presisi tinggi dan tanpa karakter emoji demi konsistensi estetika profesional.
                </p>
              </div>

              {/* Social links editor list */}
              <div className="space-y-4">
                {(draft.socialLinks || []).map((social, sIndex) => (
                  <div
                    key={social.id}
                    className="bg-white border-3 border-[#09090B] p-4 sm:p-5 neo-shadow space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-slate-200">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-100 border-2 border-[#09090B] flex items-center justify-center neo-shadow-sm">
                          <SocialIcon platform={social.platform} className="w-5 h-5 text-[#2563EB]" />
                        </div>
                        <div>
                          <h4 className="font-black text-sm sm:text-base text-[#09090B] font-['Space_Grotesk']">
                            {social.label}
                          </h4>
                          <span className="text-[10px] font-mono uppercase text-zinc-500">
                            Platform: {social.platform}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <label className="flex items-center gap-2 text-xs font-mono font-bold text-zinc-800 cursor-pointer bg-slate-50 border border-[#09090B] px-3 py-1.5 neo-shadow-sm">
                          <input
                            type="checkbox"
                            checked={social.active}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              updateDraft((prev) => {
                                const list = [...(prev.socialLinks || [])];
                                list[sIndex].active = checked;
                                return { ...prev, socialLinks: list };
                              });
                            }}
                            className="rounded-none border-2 border-black"
                          />
                          <span>{social.active ? 'Aktif (Tampil)' : 'Non-Aktif (Disembunyikan)'}</span>
                        </label>

                        <button
                          onClick={() => {
                            if (window.confirm(`Hapus media sosial '${social.label}'?`)) {
                              updateDraft((prev) => ({
                                ...prev,
                                socialLinks: (prev.socialLinks || []).filter((_, idx) => idx !== sIndex),
                              }));
                            }
                          }}
                          className="p-2 bg-red-100 hover:bg-red-200 text-red-700 border border-[#09090B] neo-shadow-sm transition-colors"
                          title="Hapus Media Sosial"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2">
                      <div className="sm:col-span-4">
                        <label className="block text-[11px] font-mono font-bold uppercase text-zinc-600 mb-1">
                          Pilih Platform (Ikon Resmi SVG)
                        </label>
                        <select
                          value={social.platform}
                          onChange={(e) => {
                            const val = e.target.value as any;
                            updateDraft((prev) => {
                              const list = [...(prev.socialLinks || [])];
                              list[sIndex].platform = val;
                              return { ...prev, socialLinks: list };
                            });
                          }}
                          className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono font-bold"
                        >
                          <option value="github">GitHub</option>
                          <option value="linkedin">LinkedIn</option>
                          <option value="twitter">Twitter / X</option>
                          <option value="instagram">Instagram</option>
                          <option value="youtube">YouTube</option>
                          <option value="telegram">Telegram</option>
                          <option value="discord">Discord</option>
                          <option value="website">Situs Web / Lainnya</option>
                        </select>
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-[11px] font-mono font-bold uppercase text-zinc-600 mb-1">
                          Label Teks Tampilan
                        </label>
                        <input
                          type="text"
                          value={social.label}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateDraft((prev) => {
                              const list = [...(prev.socialLinks || [])];
                              list[sIndex].label = val;
                              return { ...prev, socialLinks: list };
                            });
                          }}
                          placeholder="GitHub"
                          className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-bold"
                        />
                      </div>

                      <div className="sm:col-span-5">
                        <label className="block text-[11px] font-mono font-bold uppercase text-zinc-600 mb-1">
                          URL / Tautan Profil Lengkap
                        </label>
                        <input
                          type="text"
                          value={social.url}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateDraft((prev) => {
                              const list = [...(prev.socialLinks || [])];
                              list[sIndex].url = val;
                              return { ...prev, socialLinks: list };
                            });
                          }}
                          placeholder="https://github.com/username"
                          className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: ALBUM GALERI */}
          {activeTab === 'album' && (
            <div className="space-y-6 max-w-5xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                    Manajemen Album & Galeri Foto
                  </h2>
                  <p className="text-zinc-600 text-sm mt-1">
                    Tambah foto momen baru, ubah deskripsi, kategori, dan tags proyek.
                  </p>
                </div>

                <button
                  onClick={() => {
                    const newItem = {
                      id: 'alb-' + Date.now(),
                      title: 'Proyek / Galeri Baru ' + (draft.album.length + 1),
                      description: 'Deskripsi rinci mengenai arsitektur sistem dan tantangan teknis.',
                      category: 'Cybersecurity',
                      imageUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
                      tags: ['Security', 'Cloud', 'Node.js'],
                      date: '2026',
                      featured: false,
                    };
                    updateDraft((prev) => ({
                      ...prev,
                      album: [newItem, ...prev.album],
                    }));
                  }}
                  className="px-4 py-2 bg-[#2563EB] text-white border-2 border-[#09090B] font-mono text-xs font-bold neo-shadow-sm flex items-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>TAMBAH FOTO / PROYEK BARU</span>
                </button>
              </div>

              <div className="space-y-4">
                {draft.album.map((item, index) => (
                  <div
                    key={item.id}
                    className="bg-white border-3 border-[#09090B] p-4 sm:p-5 neo-shadow space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 bg-[#2563EB] text-white border border-[#09090B] text-xs font-mono font-bold">
                          #{index + 1}
                        </span>
                        <h4 className="font-black text-base font-['Space_Grotesk'] text-[#09090B]">
                          {item.title}
                        </h4>
                      </div>

                      <div className="flex items-center gap-2">
                        <label className="flex items-center gap-1.5 text-xs font-mono font-bold text-zinc-700 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={item.featured}
                            onChange={(e) => {
                              const checked = e.target.checked;
                              updateDraft((prev) => {
                                const list = [...prev.album];
                                list[index].featured = checked;
                                return { ...prev, album: list };
                              });
                            }}
                            className="rounded-none border-2 border-black"
                          />
                          Featured
                        </label>

                        <button
                          onClick={() => {
                            if (window.confirm(`Hapus item '${item.title}'?`)) {
                              updateDraft((prev) => ({
                                ...prev,
                                album: prev.album.filter((_, i) => i !== index),
                              }));
                            }
                          }}
                          className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 border border-[#09090B]"
                          title="Hapus"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                      <div className="md:col-span-4 space-y-2">
                        <label className="block text-xs font-mono font-bold uppercase text-zinc-600">
                          URL Gambar / Foto
                        </label>
                        <input
                          type="text"
                          value={item.imageUrl}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateDraft((prev) => {
                              const list = [...prev.album];
                              list[index].imageUrl = val;
                              return { ...prev, album: list };
                            });
                          }}
                          className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                        />
                        <div className="border border-[#09090B] aspect-[16/10] overflow-hidden bg-zinc-900">
                          <img
                            src={item.imageUrl}
                            alt="preview"
                            className="w-full h-full object-cover"
                          />
                        </div>
                      </div>

                      <div className="md:col-span-8 space-y-3">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-mono font-bold uppercase text-zinc-600">
                              Judul Album
                            </label>
                            <input
                              type="text"
                              value={item.title}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateDraft((prev) => {
                                  const list = [...prev.album];
                                  list[index].title = val;
                                  return { ...prev, album: list };
                                });
                              }}
                              className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] text-sm font-bold"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-mono font-bold uppercase text-zinc-600">
                              Kategori
                            </label>
                            <input
                              type="text"
                              value={item.category}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateDraft((prev) => {
                                  const list = [...prev.album];
                                  list[index].category = val;
                                  return { ...prev, album: list };
                                });
                              }}
                              className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] text-sm"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-mono font-bold uppercase text-zinc-600">
                            Deskripsi Lengkap
                          </label>
                          <textarea
                            rows={3}
                            value={item.description}
                            onChange={(e) => {
                              const val = e.target.value;
                              updateDraft((prev) => {
                                const list = [...prev.album];
                                list[index].description = val;
                                return { ...prev, album: list };
                              });
                            }}
                            className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] text-xs"
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-mono font-bold uppercase text-zinc-600">
                              Tags (Pisahkan koma)
                            </label>
                            <input
                              type="text"
                              value={item.tags.join(', ')}
                              onChange={(e) => {
                                const val = e.target.value
                                  .split(',')
                                  .map((t) => t.trim())
                                  .filter(Boolean);
                                updateDraft((prev) => {
                                  const list = [...prev.album];
                                  list[index].tags = val;
                                  return { ...prev, album: list };
                                });
                              }}
                              className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-mono font-bold uppercase text-zinc-600">
                              Tahun / Waktu
                            </label>
                            <input
                              type="text"
                              value={item.date}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateDraft((prev) => {
                                  const list = [...prev.album];
                                  list[index].date = val;
                                  return { ...prev, album: list };
                                });
                              }}
                              className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: SKILLS */}
          {activeTab === 'skills' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Manajemen Keahlian & Radar Teknologi
                </h2>
                <p className="text-zinc-600 text-sm mt-1">
                  Sesuaikan kategori, nama teknologi, persentase kemahiran, dan badge kompetensi.
                </p>
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => updateDraft((prev) => ({ ...prev, skills: [...prev.skills, { category: 'Kategori Baru', description: '', items: [] }] }))}
                  className="px-4 py-2 bg-blue-600 text-white border-2 border-[#09090B] text-xs font-mono font-bold flex items-center gap-2 neo-shadow-sm"
                ><Plus className="w-4 h-4" /> Tambah Kategori Keahlian</button>
              </div>
              <div className="space-y-6">
                {draft.skills.map((category, catIdx) => (
                  <div
                    key={catIdx}
                    className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b-2 border-[#09090B]">
                      <div className="flex-1">
                        <label className="block text-xs font-mono font-bold uppercase text-zinc-500 mb-1">
                          Nama Kategori
                        </label>
                        <input
                          type="text"
                          value={category.category}
                          onChange={(e) => {
                            const val = e.target.value;
                            updateDraft((prev) => {
                              const s = [...prev.skills];
                              s[catIdx].category = val;
                              return { ...prev, skills: s };
                            });
                          }}
                          className="w-full px-3 py-1.5 bg-slate-50 border-2 border-[#09090B] font-black text-base font-['Space_Grotesk']"
                        />
                      </div>
                      <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          if (!window.confirm(`Hapus kategori '${category.category}' beserta semua skill di dalamnya?`)) return;
                          updateDraft((prev) => ({ ...prev, skills: prev.skills.filter((_, i) => i !== catIdx) }));
                        }}
                        className="px-3 py-1.5 bg-red-100 text-red-700 border-2 border-[#09090B] text-xs font-mono font-bold flex items-center gap-1"
                      ><Trash2 className="w-3.5 h-3.5" /> Hapus Kategori</button>
                      <button
                        type="button"
                        onClick={() => {
                          const newSkill = {
                            name: 'Teknologi Baru',
                            level: 90,
                            badge: 'Expert',
                            experience: '3+ Tahun',
                          };
                          updateDraft((prev) => {
                            const s = [...prev.skills];
                            s[catIdx].items.push(newSkill);
                            return { ...prev, skills: s };
                          });
                        }}
                        className="px-3 py-1.5 bg-[#2563EB] text-white border-2 border-[#09090B] text-xs font-mono font-bold flex items-center gap-1"
                      >
                        <Plus className="w-3.5 h-3.5" />
                        <span>Tambah Skill</span>
                      </button>
                      </div>
                    </div>

                    {/* Skill items */}
                    <div className="space-y-3">
                      {category.items.map((item, itemIdx) => (
                        <div
                          key={itemIdx}
                          className="p-3 bg-slate-50 border-2 border-[#09090B] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
                        >
                          <div className="sm:col-span-5">
                            <input
                              type="text"
                              value={item.name}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateDraft((prev) => {
                                  const s = [...prev.skills];
                                  s[catIdx].items[itemIdx].name = val;
                                  return { ...prev, skills: s };
                                });
                              }}
                              className="w-full px-2.5 py-1 bg-white border border-[#09090B] text-xs font-bold"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <div className="flex items-center gap-1 font-mono text-xs">
                              <input
                                type="number"
                                min={1}
                                max={100}
                                value={item.level}
                                onChange={(e) => {
                                  const val = Number(e.target.value);
                                  updateDraft((prev) => {
                                    const s = [...prev.skills];
                                    s[catIdx].items[itemIdx].level = val;
                                    return { ...prev, skills: s };
                                  });
                                }}
                                className="w-14 px-2 py-1 bg-white border border-[#09090B] text-xs text-center font-bold"
                              />
                              <span>%</span>
                            </div>
                          </div>

                          <div className="sm:col-span-2">
                            <input
                              type="text"
                              value={item.badge}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateDraft((prev) => {
                                  const s = [...prev.skills];
                                  s[catIdx].items[itemIdx].badge = val;
                                  return { ...prev, skills: s };
                                });
                              }}
                              className="w-full px-2 py-1 bg-white border border-[#09090B] text-xs font-mono"
                            />
                          </div>

                          <div className="sm:col-span-2">
                            <input
                              type="text"
                              value={item.experience}
                              onChange={(e) => {
                                const val = e.target.value;
                                updateDraft((prev) => {
                                  const s = [...prev.skills];
                                  s[catIdx].items[itemIdx].experience = val;
                                  return { ...prev, skills: s };
                                });
                              }}
                              className="w-full px-2 py-1 bg-white border border-[#09090B] text-xs font-mono"
                            />
                          </div>

                          <div className="sm:col-span-1 flex justify-end">
                            <button
                              onClick={() => {
                                updateDraft((prev) => {
                                  const s = [...prev.skills];
                                  s[catIdx].items = s[catIdx].items.filter((_, i) => i !== itemIdx);
                                  return { ...prev, skills: s };
                                });
                              }}
                              className="p-1 bg-red-100 text-red-700 hover:bg-red-200 border border-[#09090B]"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: PROFILE & VISI IT */}
          {activeTab === 'profile' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Edit Profil, Manifesto & Visi IT
                </h2>
                <p className="text-zinc-600 text-sm mt-1">
                  Ubah narasi personal, visi masa depan, statistik pencapaian, dan jejak karir.
                </p>
              </div>

              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow space-y-4">
                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Headline Filosofi
                  </label>
                  <input
                    type="text"
                    value={draft.profile.headline}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        profile: { ...prev.profile, headline: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Manifesto Keamanan Siber (Kutipan Khas)
                  </label>
                  <textarea
                    rows={2}
                    value={draft.profile.manifesto}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        profile: { ...prev.profile, manifesto: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold uppercase mb-1">
                    Visi IT & Teknologi Masa Depan
                  </label>
                  <textarea
                    rows={3}
                    value={draft.profile.itVision}
                    onChange={(e) =>
                      updateDraft((prev) => ({
                        ...prev,
                        profile: { ...prev.profile, itVision: e.target.value },
                      }))
                    }
                    className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-sm"
                  />
                </div>

                {/* Stats Editors */}
                <div className="pt-4 border-t-2 border-slate-200">
                  <h4 className="text-xs font-mono font-bold uppercase mb-3">Statistik Pencapaian:</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {draft.profile.stats.map((stat, sIdx) => (
                      <div key={sIdx} className="p-3 bg-slate-50 border-2 border-[#09090B] space-y-2">
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={stat.value}
                            onChange={(e) => {
                              const v = e.target.value;
                              updateDraft((prev) => {
                                const st = [...prev.profile.stats];
                                st[sIdx].value = v;
                                return { ...prev, profile: { ...prev.profile, stats: st } };
                              });
                            }}
                            className="w-24 px-2 py-1 bg-white border border-[#09090B] text-sm font-black text-[#2563EB]"
                          />
                          <input
                            type="text"
                            value={stat.label}
                            onChange={(e) => {
                              const l = e.target.value;
                              updateDraft((prev) => {
                                const st = [...prev.profile.stats];
                                st[sIdx].label = l;
                                return { ...prev, profile: { ...prev.profile, stats: st } };
                              });
                            }}
                            className="flex-1 px-2 py-1 bg-white border border-[#09090B] text-xs font-bold"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: PESAN MASUK */}
          {activeTab === 'messages' && (
            <div className="space-y-6 max-w-5xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                    Pesan Masuk (Form Kontak)
                  </h2>
                  <p className="text-zinc-600 text-sm mt-1">
                    Daftar pesan terenkripsi yang dikirim pengunjung melalui formulir kontak.
                  </p>
                </div>

                <button
                  onClick={loadMessages}
                  className="px-3 py-1.5 bg-white border-2 border-[#09090B] text-xs font-mono font-bold neo-shadow-sm flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Segarkan Data</span>
                </button>
              </div>

              {messagesLoading ? (
                <div className="p-8 text-center font-mono text-zinc-500">Memuat pesan dari database...</div>
              ) : messages.length === 0 ? (
                <div className="bg-white border-3 border-[#09090B] neo-shadow p-8 text-center">
                  <Mail className="w-10 h-10 text-zinc-400 mx-auto mb-2" />
                  <p className="font-bold text-sm">Belum ada pesan masuk dari pengunjung.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`p-5 border-3 border-[#09090B] neo-shadow transition-all ${
                        msg.status === 'unread' ? 'bg-amber-50' : 'bg-white'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b-2 border-slate-200">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-black text-base text-[#09090B] font-['Space_Grotesk']">
                              {msg.name}
                            </span>
                            <span
                              className={`px-2 py-0.5 text-[10px] font-mono font-bold border border-[#09090B] ${
                                msg.status === 'unread'
                                  ? 'bg-amber-300 text-[#09090B]'
                                  : 'bg-slate-200 text-zinc-700'
                              }`}
                            >
                              {msg.status.toUpperCase()}
                            </span>
                          </div>
                          <p className="text-xs font-mono text-zinc-500">
                            {msg.email} • IP: {msg.ip || '127.0.0.1'} • {new Date(msg.createdAt).toLocaleString('id-ID')}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleToggleMessageStatus(msg.id, msg.status)}
                            className="px-2.5 py-1 bg-white hover:bg-slate-100 border border-[#09090B] text-xs font-mono font-bold"
                          >
                            Tandai {msg.status === 'unread' ? 'Dibaca' : 'Belum Dibaca'}
                          </button>
                          <button
                            onClick={() => handleDeleteMessage(msg.id)}
                            className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 border border-[#09090B]"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="pt-3 space-y-1">
                        <div className="text-xs font-mono font-bold text-[#2563EB]">
                          Subjek: {msg.subject}
                        </div>
                        <p className="text-sm text-zinc-800 whitespace-pre-wrap leading-relaxed">
                          {msg.message}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 8: KELOLA ADMIN BARU */}
          {activeTab === 'admins' && (
            <div className="space-y-6 max-w-4xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Kelola Akun Admin & Create Admin Baru
                </h2>
                <p className="text-zinc-600 text-sm mt-1">
                  Berikan izin admin ke akun yang sudah ada di Firebase Authentication. Form ini tidak membuat akun atau password baru.
                </p>
              </div>

              {/* Form Create Admin Baru */}
              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow space-y-4">
                <h3 className="text-base font-black font-['Space_Grotesk'] flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-[#2563EB]" />
                  <span>Daftarkan Akun Admin Tambahan</span>
                </h3>

                {createAdminMsg && (
                  <div
                    className={`p-3 border-2 border-[#09090B] text-xs font-mono font-bold ${
                      createAdminMsg.error ? 'bg-red-100 text-red-900' : 'bg-emerald-100 text-emerald-900'
                    }`}
                  >
                    {createAdminMsg.text}
                  </div>
                )}

                <form onSubmit={handleCreateNewAdmin} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-mono font-bold uppercase mb-1">
                        Email / User Admin *
                      </label>
                      <input
                        type="text"
                        required
                        value={newAdminUser}
                        onChange={(e) => setNewAdminUser(e.target.value)}
                        placeholder="email-akun-yang-sudah-ada@domain.com"
                        className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-mono font-bold uppercase mb-1">
                        Peran (Role)
                      </label>
                      <select
                        value={newAdminRole}
                        onChange={(e) => setNewAdminRole(e.target.value as any)}
                        className="w-full px-3 py-2 bg-slate-50 border-2 border-[#09090B] text-xs font-mono font-bold"
                      >
                        <option value="admin">Admin Standard</option>
                        <option value="superadmin">Superadmin</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="px-5 py-2.5 bg-[#2563EB] text-white font-mono text-xs font-bold uppercase border-2 border-[#09090B] neo-shadow-sm hover:bg-blue-600 transition-colors"
                  >
                    + Daftarkan Admin Baru
                  </button>
                </form>
              </div>

              {/* List of current admins */}
              <div className="bg-white border-3 border-[#09090B] p-6 neo-shadow space-y-4">
                <h3 className="text-base font-black font-['Space_Grotesk']">
                  Daftar Admin Aktif di Database
                </h3>

                <div className="space-y-2">
                  {adminsList.length === 0 && <p className="text-sm text-slate-500 border border-dashed border-slate-300 p-4">Belum ada data admin yang dapat ditampilkan, atau akses daftar admin ditolak oleh Firestore.</p>}
                  {adminsList.map((admin) => (
                    <div
                      key={admin.id}
                      className="p-3 bg-slate-50 border-2 border-[#09090B] flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-[#09090B] text-white flex items-center justify-center font-bold text-xs font-mono">
                          {admin.username[0].toUpperCase()}
                        </div>
                        <div>
                          <div className="font-bold text-sm font-mono flex items-center gap-2">
                            <span>{admin.username}</span>
                            {admin.username === currentAdmin?.username && (
                              <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 border border-blue-400">
                                Sesi Anda
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] font-mono text-zinc-500 uppercase">
                            Role: {admin.role}
                          </span>
                        </div>
                      </div>

                      {admin.username !== currentAdmin?.username && (
                        <button
                          onClick={() => handleDeleteAdmin(admin.id, admin.username)}
                          className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 border border-[#09090B]"
                          title="Hapus Akun Admin"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}


          {/* FULL ACCESS WEBSITE BUILDER */}
          {activeTab === 'site' && (
            <div className="space-y-6 max-w-6xl">
              <div>
                <h2 className="text-2xl font-black text-[#09090B] font-['Space_Grotesk']">FULL ACCESS ADMIN • ALL CONTENT</h2>
                <p className="text-sm text-zinc-600 mt-1">Pusat kendali admin: edit data konten yang tersimpan, identitas, tema, section, dan CSS. Gunakan Advanced JSON untuk mengubah seluruh struktur data yang didukung; lalu simpan ke Firestore.</p>
              </div>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div><h3 className="font-black text-lg">Maintenance Mode</h3><p className="text-sm text-zinc-600">Saat aktif, pengunjung publik melihat halaman maintenance. Route admin tetap bisa dibuka.</p></div>
                  <label className="inline-flex items-center gap-3 font-bold text-sm"><span>{draft.siteConfig.maintenanceMode ? 'AKTIF' : 'NONAKTIF'}</span><input type="checkbox" className="h-5 w-5 accent-red-600" checked={!!draft.siteConfig.maintenanceMode} onChange={e => updateDraft(prev => ({...prev, siteConfig:{...prev.siteConfig, maintenanceMode:e.target.checked}}))} /></label>
                </div>
                <label className="block text-xs font-mono font-bold uppercase space-y-1">Pesan Maintenance<textarea rows={3} value={String(draft.siteConfig.maintenanceMessage || '')} onChange={e => updateDraft(prev => ({...prev, siteConfig:{...prev.siteConfig, maintenanceMessage:e.target.value}}))} placeholder="Kami sedang melakukan pembaruan..." className="w-full px-3 py-2 border-2 border-slate-300 font-sans font-normal text-sm normal-case" /></label>
                <div className="flex flex-wrap gap-2"><button type="button" onClick={saveLocalDraft} className="px-3 py-2 border-2 border-black font-bold text-sm">Simpan Draft Lokal</button><button type="button" onClick={restoreLocalDraft} className="px-3 py-2 border-2 border-black font-bold text-sm">Pulihkan Draft</button><button type="button" onClick={handleSaveToFirestore} disabled={saveLoading} className="px-3 py-2 bg-blue-600 text-white border-2 border-black font-bold text-sm">Publish / Simpan ke Firestore</button></div>
                {siteToolFeedback && <p role="status" className="text-sm font-bold text-blue-700">{siteToolFeedback}</p>}
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <h3 className="font-black text-lg">Favicon & SEO</h3>
                <label className="block text-xs font-mono font-bold uppercase space-y-1">Favicon URL<input value={String(draft.siteConfig.faviconUrl || '')} onChange={e => updateDraft(prev => ({...prev, siteConfig:{...prev.siteConfig, faviconUrl:e.target.value}}))} placeholder="https://domain.com/favicon.png" className="w-full px-3 py-2 border-2 border-slate-300 font-sans font-normal text-sm normal-case" /></label>
                {draft.siteConfig.faviconUrl && <img src={draft.siteConfig.faviconUrl} alt="Preview favicon" className="h-10 w-10 object-contain border p-1" />}
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <h3 className="font-black text-lg">Preview Responsif & Riwayat</h3>
                <div className="flex flex-wrap gap-2">{(['mobile','tablet','desktop'] as const).map(mode => <button key={mode} type="button" onClick={() => setPreviewWidth(mode)} className={`px-3 py-2 border-2 border-black text-sm font-bold ${previewWidth===mode?'bg-blue-600 text-white':'bg-white'}`}>{mode.toUpperCase()}</button>)}</div>
                <div className="mx-auto border-4 border-zinc-800 rounded-xl overflow-hidden bg-white transition-all" style={{width:previewWidth==='mobile'?'320px':previewWidth==='tablet'?'600px':'100%',maxWidth:'100%'}}><div className="p-4 sm:p-6" style={{backgroundColor:draft.siteConfig.backgroundColor || '#F8FAFC',color:draft.siteConfig.textColor || '#09090B'}}><p className="text-xs opacity-60">LIVE THEME PREVIEW • {previewWidth}</p><h4 className="text-2xl font-black mt-2">{draft.hero.name || 'Nama Portfolio'}</h4><p className="mt-1" style={{color:draft.siteConfig.accentColor || '#2563EB'}}>{draft.hero.title || draft.hero.tagline}</p><p className="mt-3 text-sm">{draft.hero.bio}</p><div className="mt-4 inline-block px-4 py-2 text-white font-bold" style={{backgroundColor:draft.siteConfig.accentColor || '#2563EB'}}>{draft.hero.primaryCtaText || 'Hubungi Saya'}</div></div></div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4"><div><h4 className="font-black mb-2">Revision History (browser lokal)</h4>{revisionHistory.length===0?<p className="text-sm text-zinc-500">Belum ada revisi tersimpan.</p>:revisionHistory.map((rev,i)=><div key={rev.at+i} className="border p-3 mb-2 flex flex-wrap items-center justify-between gap-2 text-xs"><span>{new Date(rev.at).toLocaleString()} • {rev.by}</span><button type="button" className="underline font-bold" onClick={()=>{try{setDraft(JSON.parse(rev.snapshot) as PortfolioData);setIsDirty(true);setSiteToolFeedback('Revisi dipulihkan ke draft. Publish untuk menerapkan.');recordActivity('Memulihkan revisi '+new Date(rev.at).toLocaleString());}catch{setSiteToolFeedback('Revisi tidak valid.');}}}>Pulihkan</button></div>)}</div><div><h4 className="font-black mb-2">Activity Log (browser lokal)</h4>{activityHistory.length===0?<p className="text-sm text-zinc-500">Belum ada aktivitas tercatat.</p>:activityHistory.slice(0,10).map((item,i)=><div key={item.at+i} className="border-b py-2 text-xs"><strong>{item.action}</strong><p className="text-zinc-500">{new Date(item.at).toLocaleString()} • {item.by}</p></div>)}</div></div>
                <p className="text-xs text-amber-700">Preview ini menunjukkan tema dan konten hero utama, bukan rendering penuh website. Riwayat dan log tersimpan di browser ini saja, bukan di cloud.</p>
              </section>

              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <h3 className="font-black text-lg">SEO & Identitas Situs</h3>
                {([
                  ['pageTitle','Judul tab / SEO title'],
                  ['pageDescription','Deskripsi SEO'],
                  ['footerText','Teks footer'],
                  ['copyrightYear','Tahun copyright'],
                  ['contactEmail','Email kontak'],
                  ['contactPhone','Nomor telepon'],
                  ['location','Lokasi'],
                  ['githubUrl','URL GitHub'],
                  ['linkedinUrl','URL LinkedIn'],
                  ['twitterUrl','URL Twitter / X'],
                ] as Array<[string,string]>).map(([key,label]) => (
                  <label key={key} className="block text-xs font-mono font-bold uppercase space-y-1">
                    {label}
                    <input value={String((draft.siteConfig as any)?.[key] ?? '')}
                      onChange={(e) => updateDraft(prev => ({...prev, siteConfig:{...prev.siteConfig,[key]:e.target.value}}))}
                      className="w-full px-3 py-2 border-2 border-slate-300 focus:border-blue-600 outline-none normal-case font-sans font-normal text-sm" />
                  </label>
                ))}
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <div>
                  <h3 className="font-black text-lg">Editor Tulisan Seluruh Halaman</h3>
                  <p className="text-sm text-zinc-600">Ubah teks statis yang sebelumnya tertanam di komponen. Kosongkan kolom untuk kembali ke teks bawaan. Teks dinamis seperti nama, deskripsi proyek, skill, dan profil tetap diedit melalui tab masing-masing.</p>
                </div>
                {([
                  ['navbarBrand','Nama brand navbar'],['navbarSubtext','Subjudul navbar'],
                  ['heroTitleLead','Judul hero - bagian utama'],['heroTitleEnd','Judul hero - bagian akhir'],
                  ['heroStatOneValue','Hero statistik 1 - nilai'],['heroStatOneLabel','Hero statistik 1 - label'],
                  ['heroStatTwoValue','Hero statistik 2 - nilai'],['heroStatTwoLabel','Hero statistik 2 - label'],
                  ['heroStatThreeValue','Hero statistik 3 - nilai'],['heroStatThreeLabel','Hero statistik 3 - label'],
                  ['albumEyebrow','Album - label kecil'],['albumTitle','Album - judul'],['albumDescription','Album - deskripsi'],['albumCounterLabel','Album - label jumlah'],['albumCounterSuffix','Album - satuan jumlah'],['albumEmptyTitle','Album kosong - judul'],['albumEmptyDescription','Album kosong - deskripsi'],
                  ['skillsEyebrow','Skill - label kecil'],['skillsTitle','Skill - judul'],['skillsDescription','Skill - deskripsi'],['skillsExperiencePrefix','Skill - label pengalaman'],['skillsMeterLabel','Skill - label meter kemampuan'],['skillsFooterText','Skill - teks footer'],['skillsVerifiedLabel','Skill - label verifikasi'],
                  ['profileEyebrow','Profil - label kecil'],['profileTitle','Profil - judul'],['profileDescription','Profil - deskripsi'],['profileManifestoLabel','Profil - label manifesto'],['profileManifestoTitle','Profil - judul manifesto'],['profileVisionLabel','Profil - label visi'],['profileTimelineTitle','Profil - judul timeline'],
                  ['contactTitle','Kontak - judul'],['contactDescription','Kontak - deskripsi'],['contactSuccess','Kontak - pesan berhasil'],['contactError','Kontak - pesan gagal'],['footerDescription','Footer - deskripsi']
                ] as Array<[string,string]>).map(([key,label]) => (
                  <label key={key} className="block text-xs font-mono font-bold uppercase space-y-1">
                    {label}
                    <textarea rows={key.toLowerCase().includes('description') || key.toLowerCase().includes('title') ? 2 : 1} value={String(draft.siteConfig.pageCopy?.[key] ?? '')}
                      onChange={(e) => updateDraft(prev => ({...prev, siteConfig:{...prev.siteConfig, pageCopy:{...(prev.siteConfig.pageCopy || {}), [key]:e.target.value}}}))}
                      placeholder="Gunakan teks bawaan jika dikosongkan"
                      className="w-full px-3 py-2 border-2 border-slate-300 focus:border-blue-600 outline-none normal-case font-sans font-normal text-sm" />
                  </label>
                ))}
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <h3 className="font-black text-lg">Tema Global</h3>
                <p className="text-xs text-zinc-500">Warna ini diterapkan sebagai CSS variables global pada halaman publik.</p>
                {([
                  ['backgroundColor','Warna background'],
                  ['textColor','Warna teks'],
                  ['accentColor','Warna aksen'],
                ] as Array<[string,string]>).map(([key,label]) => (
                  <div key={key} className="flex items-center gap-3">
                    <input type="color" aria-label={label} value={String((draft.siteConfig as any)?.[key] || (key==='backgroundColor'?'#F8FAFC':key==='textColor'?'#09090B':'#2563EB'))}
                      onChange={(e) => updateDraft(prev=>({...prev,siteConfig:{...prev.siteConfig,[key]:e.target.value}}))}
                      className="w-12 h-10 border-2 border-slate-300" />
                    <label className="text-sm font-bold flex-1">{label}</label>
                    <code className="text-xs">{String((draft.siteConfig as any)?.[key] || '')}</code>
                  </div>
                ))}
                <label className="block text-xs font-mono font-bold uppercase space-y-1">Custom CSS
                  <textarea rows={8} value={String((draft.siteConfig as any)?.customCss ?? '')}
                    onChange={(e)=>updateDraft(prev=>({...prev,siteConfig:{...prev.siteConfig,customCss:e.target.value}}))}
                    placeholder="/* CSS khusus halaman publik */"
                    className="w-full px-3 py-2 border-2 border-slate-300 font-mono normal-case text-sm" />
                </label>
                <p className="text-xs text-amber-700">Catatan keamanan: hanya masukkan CSS tepercaya. Jangan tempel JavaScript atau kode dari sumber tidak dikenal.</p>
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <h3 className="font-black text-lg">Kontrol Section Halaman Utama</h3>
                <p className="text-sm text-zinc-600">Atur section yang terlihat dan urutannya dari atas ke bawah. Navbar dan footer tetap dikelola terpisah.</p>
                {(() => {
                  const defaults = ['hero','album','skills','profile','contact'];
                  const custom = draft.siteConfig.customSections || [];
                  const allIds = [...defaults, ...custom.map(section => section.id)];
                  const order = [...new Set([...(draft.siteConfig.sectionOrder || []), ...allIds])].filter(x=>allIds.includes(x));
                  const hidden = draft.siteConfig.hiddenSections || [];
                  const labels: Record<string,string> = {hero:'Hero / Beranda',album:'Album & Proyek',skills:'Keahlian',profile:'Profil & Visi',contact:'Kontak'};
                  custom.forEach(section => { labels[section.id] = section.title || 'Section custom'; });
                  const move = (name:string,delta:number) => {
                    const next=[...order]; const i=next.indexOf(name); const j=i+delta;
                    if(j<0||j>=next.length)return;
                    [next[i],next[j]]=[next[j],next[i]];
                    updateDraft(prev=>({...prev,siteConfig:{...prev.siteConfig,sectionOrder:next}}));
                  };
                  return order.map((name,i)=>(
                    <div key={name} className="flex flex-wrap items-center gap-3 border-2 border-slate-200 p-3">
                      <div className="flex gap-1">
                        <button type="button" disabled={i===0} onClick={()=>move(name,-1)} className="px-2 py-1 border border-slate-400 disabled:opacity-30">↑</button>
                        <button type="button" disabled={i===order.length-1} onClick={()=>move(name,1)} className="px-2 py-1 border border-slate-400 disabled:opacity-30">↓</button>
                      </div>
                      <span className="font-bold flex-1">{i+1}. {labels[name]}</span>
                      <label className="text-xs font-bold flex items-center gap-2">
                        <input type="checkbox" checked={!hidden.includes(name)} onChange={(e)=>{
                          const next=e.target.checked?hidden.filter(x=>x!==name):[...hidden,name];
                          updateDraft(prev=>({...prev,siteConfig:{...prev.siteConfig,hiddenSections:next}}));
                        }} />
                        Tampilkan section
                      </label>
                    </div>
                  ));
                })()}
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="font-black text-lg">Page Builder • Tambah / Edit / Hapus Section</h3>
                    <p className="text-sm text-zinc-600">Buat section bebas di bagian mana pun, ubah seluruh konten dan tombolnya, lalu atur posisinya di kontrol urutan section.</p>
                  </div>
                  <button type="button" onClick={() => {
                    const id = `custom-${Date.now()}`;
                    const section = { id, eyebrow: 'SECTION BARU', title: 'Judul section baru', body: 'Tulis konten halaman di sini...', imageUrl: '', buttonText: '', buttonUrl: '', backgroundColor: '#FFFFFF', visible: true };
                    updateDraft(prev => ({ ...prev, siteConfig: { ...prev.siteConfig, customSections: [...(prev.siteConfig.customSections || []), section], sectionOrder: [...(prev.siteConfig.sectionOrder || ['hero','album','skills','profile','contact']), id] } }));
                  }} className="px-4 py-2 bg-blue-600 text-white border-2 border-black font-bold flex items-center gap-2"><Plus className="w-4 h-4" /> Tambah Section</button>
                </div>
                {(draft.siteConfig.customSections || []).length === 0 && <p className="p-4 bg-slate-50 border border-dashed border-slate-300 text-sm text-zinc-500">Belum ada section custom. Klik “Tambah Section” untuk membuat bagian halaman baru.</p>}
                {(draft.siteConfig.customSections || []).map((section, index) => {
                  const updateSection = (field: string, value: string | boolean) => updateDraft(prev => ({ ...prev, siteConfig: { ...prev.siteConfig, customSections: (prev.siteConfig.customSections || []).map(item => item.id === section.id ? { ...item, [field]: value } : item) } }));
                  const removeSection = () => {
                    if (!window.confirm(`Hapus section “${section.title || section.id}”?`)) return;
                    updateDraft(prev => ({ ...prev, siteConfig: { ...prev.siteConfig, customSections: (prev.siteConfig.customSections || []).filter(item => item.id !== section.id), sectionOrder: (prev.siteConfig.sectionOrder || []).filter(id => id !== section.id), hiddenSections: (prev.siteConfig.hiddenSections || []).filter(id => id !== section.id) } }));
                  };
                  return <div key={section.id} className="border-2 border-slate-300 p-4 space-y-3">
                    <div className="flex items-center justify-between gap-2"><h4 className="font-black">Section {index + 1}</h4><div className="flex items-center gap-3"><label className="text-xs font-bold flex items-center gap-2"><input type="checkbox" checked={section.visible !== false} onChange={e => updateSection('visible', e.target.checked)} />Aktif</label><button type="button" onClick={removeSection} className="text-red-600 font-bold flex items-center gap-1"><Trash2 className="w-4 h-4"/> Hapus</button></div></div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {([['eyebrow','Label kecil / eyebrow'],['title','Judul'],['imageUrl','URL gambar'],['buttonText','Teks tombol'],['buttonUrl','Link tombol']] as Array<[string,string]>).map(([field,label]) => <label key={field} className="block text-xs font-bold space-y-1">{label}<input value={String((section as any)[field] ?? '')} onChange={e => updateSection(field,e.target.value)} className="w-full px-3 py-2 border-2 border-slate-300 font-normal text-sm" /></label>)}
                      <label className="block text-xs font-bold space-y-1">Warna background<input type="color" value={section.backgroundColor || '#FFFFFF'} onChange={e => updateSection('backgroundColor',e.target.value)} className="w-full h-10 border-2 border-slate-300" /></label>
                    </div>
                    <label className="block text-xs font-bold space-y-1">Isi / paragraf / teks panjang<textarea rows={5} value={section.body} onChange={e => updateSection('body',e.target.value)} className="w-full px-3 py-2 border-2 border-slate-300 font-normal text-sm" /></label>
                  </div>;
                })}
              </section>
              <section className="bg-white border-3 border-[#09090B] p-5 neo-shadow space-y-4">
                <div>
                  <h3 className="font-black text-lg">FULL ACCESS • EDIT SEMUA DATA WEBSITE</h3>
                  <p className="text-sm text-zinc-600 mt-1">Editor lanjutan untuk mengubah semua field data website sekaligus, termasuk teks atau properti yang belum memiliki form khusus. Format harus JSON valid. Setelah menerapkan, klik SIMPAN KE FIRESTORE di bar atas.</p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button type="button" onClick={() => { setJsonEditorText(JSON.stringify(draft, null, 2)); setJsonEditorFeedback('Data editor dimuat ulang dari draft saat ini.'); }} className="px-3 py-2 border-2 border-black font-bold text-sm">Muat Data Saat Ini</button>
                  <button type="button" onClick={() => { try { const parsed = JSON.parse(jsonEditorText); if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || !parsed.hero || !parsed.navigation || !parsed.siteConfig || !Array.isArray(parsed.album) || !Array.isArray(parsed.skills) || !parsed.profile || !Array.isArray(parsed.socialLinks)) throw new Error('Struktur wajib: hero, navigation, album[], skills[], profile, siteConfig, dan socialLinks[].'); setDraft(parsed as PortfolioData); setIsDirty(true); setJsonEditorFeedback('JSON berhasil diterapkan ke draft. Tekan SIMPAN KE FIRESTORE untuk menyimpan.'); } catch (error) { setJsonEditorFeedback('JSON tidak valid: ' + (error instanceof Error ? error.message : String(error))); } }} className="px-3 py-2 bg-blue-600 text-white border-2 border-black font-bold text-sm">Terapkan JSON ke Draft</button>
                  <button type="button" onClick={() => { navigator.clipboard?.writeText(JSON.stringify(draft, null, 2)); setJsonEditorFeedback('Data draft disalin ke clipboard jika izin browser tersedia.'); }} className="px-3 py-2 border-2 border-black font-bold text-sm">Salin Data Draft</button>
                </div>
                {jsonEditorFeedback && <p role="status" className="text-sm font-bold text-blue-700">{jsonEditorFeedback}</p>}
                <textarea aria-label="JSON seluruh data website" spellCheck={false} rows={24} value={jsonEditorText} onChange={(e) => setJsonEditorText(e.target.value)} className="w-full min-w-0 p-3 border-2 border-slate-400 font-mono text-xs sm:text-sm leading-6 outline-none focus:border-blue-600" />
                <p className="text-xs text-amber-700">Tips: jangan menghapus field wajib. Buat salinan JSON sebelum perubahan besar. Menerapkan JSON hanya mengubah draft lokal sampai tombol simpan Firestore ditekan.</p>
              </section>
              <div className="p-4 bg-blue-50 border-2 border-blue-300 text-sm">
                <strong>Kontrol admin:</strong> edit lewat tab khusus atau gunakan editor JSON untuk akses ke seluruh data konten. Tambahkan section bebas di Page Builder. Klik <strong>SIMPAN KE FIRESTORE</strong> untuk menerapkan perubahan.
              </div>
            </div>
          )}

        </main>
      </div>
    </div>
  );
};
