import React from 'react';
import { ArrowUp, Terminal, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { PortfolioData } from '../types';
import { SocialIcon } from './common/SocialIcon';

interface FooterProps {
  siteConfig: PortfolioData['siteConfig'];
  navigation: PortfolioData['navigation'];
  socialLinks?: PortfolioData['socialLinks'];
  pageCopy?: Record<string, string>;
}

export const Footer: React.FC<FooterProps> = ({ siteConfig, navigation, socialLinks = [], pageCopy = {} }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeSocials = socialLinks.filter((s) => s.active);

  return (
    <footer className="bg-[#09090B] text-white border-t-3 border-[#09090B] pt-16 pb-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Brand Info */}
          <div className="md:col-span-6 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[#2563EB] text-white border-2 border-white flex items-center justify-center font-black text-xl font-['Space_Grotesk'] neo-shadow-sm">
                L
              </div>
              <span className="text-2xl font-black font-['Space_Grotesk'] tracking-tight">
                {navigation.brandName}
              </span>
            </div>
            <p className="text-zinc-400 text-sm max-w-md leading-relaxed">
              {pageCopy.footerDescription || siteConfig.footerText}
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-zinc-900 border border-zinc-700 text-xs font-mono text-zinc-300">
              <Terminal className="w-3.5 h-3.5 text-[#2563EB]" />
              <span>STACK: REACT 19 • FIREBASE FIRESTORE • NODE.JS • TAILWIND</span>
            </div>

            {/* Official Social Media Links */}
            {activeSocials.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {activeSocials.map((social) => (
                  <a
                    key={social.id}
                    href={social.url}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 bg-zinc-900 hover:bg-[#2563EB] text-zinc-300 hover:text-white border border-zinc-700 hover:border-white transition-all text-xs flex items-center gap-1.5"
                    title={social.label}
                  >
                    <SocialIcon platform={social.platform} className="w-3.5 h-3.5" />
                    <span className="font-mono text-[11px]">{social.label}</span>
                  </a>
                ))}
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">
              NAVIGASI CEPAT
            </h4>
            <ul className="space-y-2 text-sm font-bold">
              {navigation.menuItems.map((item) => (
                <li key={item.id}>
                  <a
                    href={item.href}
                    className="text-zinc-300 hover:text-[#2563EB] transition-colors flex items-center gap-1.5"
                  >
                    <span>→</span> {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Cyber Security Seal & Architecture Status (Public Isolation) */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-400">
              SERTIFIKASI SIBER & STATUS
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Infrastruktur terproteksi berlapis dengan arsitektur Zero-Trust, rate limiting anti-DDoS, dan audit integritas data Firebase Cloud Firestore.
            </p>
            <div className="p-3 bg-zinc-900 border border-zinc-700 text-xs font-mono space-y-1.5">
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>HELMET HEADERS ACTIVE</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>EXPRESS RATE LIMITER ARMED</span>
              </div>
              <div className="text-[10px] text-zinc-400">
                AES-256 & Bcrypt Encrypted
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-zinc-500">
          <div>
            © {siteConfig.copyrightYear} {navigation.brandName}. All rights reserved. Zero-Trust Security Compliant.
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors bg-zinc-900 px-3 py-1.5 border border-zinc-700 hover:border-white"
          >
            <span>KEMBALI KE ATAS</span>
            <ArrowUp className="w-3.5 h-3.5 text-[#2563EB]" />
          </button>
        </div>
      </div>
    </footer>
  );
};
