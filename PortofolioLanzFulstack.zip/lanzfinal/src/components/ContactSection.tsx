import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Send, Mail, MapPin, Phone, ShieldCheck, AlertCircle, CheckCircle2, Lock } from 'lucide-react';
import { PortfolioData } from '../types';
import { firestoreService } from '../services/firestoreService';
import { smoothEase, slickEase, StaggerHeading, StaggerParagraph } from './motion/MotionText';
import { SocialIcon } from './common/SocialIcon';

interface ContactSectionProps {
  siteConfig: PortfolioData['siteConfig'];
  socialLinks?: PortfolioData['socialLinks'];
  pageCopy?: Record<string, string>;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ siteConfig, socialLinks = [], pageCopy = {} }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setLoading(true);

    try {
      await firestoreService.sendContactMessage(formData);
      setSuccessMessage(pageCopy.contactSuccess || 'Pesan Anda berhasil terkirim dan tersimpan aman di Firebase Firestore!');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (err: any) {
      setErrorMessage(err.message || pageCopy.contactError || 'Gagal mengirim pesan. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <section id="kontak" className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 bg-slate-100 border-t-3 border-[#09090B]">
      <div className="max-w-7xl mx-auto">
        
        {/* Section Header with Staggered Reveal */}
        <div className="max-w-3xl mb-12">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: smoothEase }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-[#2563EB] text-white border-2 border-[#09090B] neo-shadow-sm text-xs font-black uppercase font-mono tracking-wider mb-3"
          >
            <Mail className="w-3.5 h-3.5" />
            HUBUNGI SECARA LANGSUNG
          </motion.div>

          <h2 className="text-3xl sm:text-5xl font-black text-[#09090B] tracking-tight font-['Space_Grotesk']">
            <StaggerHeading text={pageCopy.contactTitle || "Mulai Diskusi & Kolaborasi Tingkat Lanjut"} as="span" />
          </h2>

          <StaggerParagraph
            text={pageCopy.contactDescription || "Kirimkan pesan Anda untuk kebutuhan arsitektur sistem, audit keamanan siber, atau pengembangan web modern berskala besar."}
            className="text-zinc-600 font-medium mt-3 text-sm sm:text-base leading-relaxed"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Contact Info & Security Guarantee */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: smoothEase }}
            className="lg:col-span-5 space-y-6"
          >
            <div className="bg-white border-3 border-[#09090B] neo-shadow p-6 sm:p-8 space-y-6">
              <h3 className="text-xl font-black text-[#09090B] font-['Space_Grotesk']">
                Saluran Komunikasi Resmi
              </h3>

              <div className="space-y-4 text-sm font-mono">
                <a
                  href={`mailto:${siteConfig.contactEmail}`}
                  className="flex items-center gap-3 p-3 bg-slate-50 border-2 border-[#09090B] hover:bg-yellow-200 transition-colors"
                >
                  <div className="p-2 bg-[#2563EB] text-white border border-[#09090B]">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-zinc-500 uppercase">EMAIL RESMI</div>
                    <div className="font-bold text-[#09090B]">{siteConfig.contactEmail}</div>
                  </div>
                </a>

                <a
                  href={`tel:${siteConfig.contactPhone}`}
                  className="flex items-center gap-3 p-3 bg-slate-50 border-2 border-[#09090B] hover:bg-yellow-200 transition-colors"
                >
                  <div className="p-2 bg-[#2563EB] text-white border border-[#09090B]">
                    <Phone className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-zinc-500 uppercase">TELEPON / WA</div>
                    <div className="font-bold text-[#09090B]">{siteConfig.contactPhone}</div>
                  </div>
                </a>

                <div className="flex items-center gap-3 p-3 bg-slate-50 border-2 border-[#09090B]">
                  <div className="p-2 bg-[#09090B] text-white border border-[#09090B]">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] font-bold text-zinc-500 uppercase">LOKASI BASIS</div>
                    <div className="font-bold text-[#09090B]">{siteConfig.location}</div>
                  </div>
                </div>
              </div>

              {/* Social Channels (Official Icons, No Emojis) */}
              <div className="pt-4 border-t-2 border-slate-200">
                <p className="text-xs font-mono font-bold uppercase text-zinc-500 mb-3">
                  JARINGAN MEDIA SOSIAL RESMI:
                </p>
                <div className="flex flex-wrap gap-2.5">
                  {socialLinks.filter((s) => s.active).map((social) => (
                    <motion.a
                      key={social.id}
                      href={social.url}
                      target="_blank"
                      rel="noreferrer"
                      whileHover={{ scale: 1.05, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      transition={{ duration: 0.2, ease: slickEase }}
                      className="inline-flex items-center gap-2 px-3 py-2 bg-white text-[#09090B] border-2 border-[#09090B] neo-shadow-sm hover:bg-[#2563EB] hover:text-white transition-colors text-xs font-mono font-bold"
                      title={social.label}
                    >
                      <SocialIcon platform={social.platform} className="w-4 h-4 shrink-0" />
                      <span>{social.label}</span>
                    </motion.a>
                  ))}
                </div>
              </div>
            </div>

            {/* Cyber Security Notice */}
            <div className="bg-[#09090B] text-white border-3 border-[#09090B] neo-shadow-blue p-5 font-mono text-xs space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold uppercase">
                <ShieldCheck className="w-4 h-4" />
                <span>KEAMANAN DATA TERVERIFIKASI</span>
              </div>
              <p className="text-zinc-300 leading-relaxed text-[11px]">
                Semua input pesan disanitasi secara otomatis terhadap serangan NoSQL Injection, XSS, dan diproteksi oleh rate limiter IP untuk mencegah spam.
              </p>
            </div>
          </motion.div>

          {/* Right: Real-time Form */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, delay: 0.15, ease: smoothEase }}
            className="lg:col-span-7"
          >
            <div className="bg-white border-3 border-[#09090B] neo-shadow-lg p-6 sm:p-8">
              
              <div className="flex items-center justify-between pb-4 border-b-2 border-[#09090B] mb-6">
                <h3 className="text-xl font-black text-[#09090B] font-['Space_Grotesk']">
                  Formulir Pesan Terenkripsi
                </h3>
                <span className="text-[11px] font-mono font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 border border-[#09090B] flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-700" />
                  SSL // RATE-LIMITED
                </span>
              </div>

              {/* Feedback Alerts */}
              {successMessage && (
                <div className="mb-6 p-4 bg-emerald-100 border-2 border-[#09090B] neo-shadow-sm flex items-start gap-3 text-emerald-900">
                  <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-sm">Pesan Berhasil Terkirim!</h4>
                    <p className="text-xs mt-0.5">{successMessage}</p>
                  </div>
                </div>
              )}

              {errorMessage && (
                <div className="mb-6 p-4 bg-red-100 border-2 border-[#09090B] neo-shadow-sm flex items-start gap-3 text-red-900">
                  <AlertCircle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-sm">Gagal Mengirim</h4>
                    <p className="text-xs mt-0.5">{errorMessage}</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-1.5">
                    <label className="block text-xs font-mono font-bold uppercase text-[#09090B]">
                      Nama Lengkap *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="cth. Alexander Kurniawan"
                      className="w-full px-4 py-3 bg-slate-50 border-2 border-[#09090B] font-medium text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2563EB]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-mono font-bold uppercase text-[#09090B]">
                      Alamat Email *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="nama@perusahaan.com"
                      className="w-full px-4 py-3 bg-slate-50 border-2 border-[#09090B] font-medium text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2563EB]"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-mono font-bold uppercase text-[#09090B]">
                    Subjek Diskusi / Proyek *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    placeholder="cth. Konsultasi Arsitektur Web & Penetrasi Keamanan"
                    className="w-full px-4 py-3 bg-slate-50 border-2 border-[#09090B] font-medium text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2563EB]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-mono font-bold uppercase text-[#09090B]">
                    Detail Pesan / Pertanyaan *
                  </label>
                  <textarea
                    rows={5}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tuliskan spesifikasi sistem, timeline, atau pertanyaan teknis Anda di sini..."
                    className="w-full px-4 py-3 bg-slate-50 border-2 border-[#09090B] font-medium text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-[#2563EB] resize-y"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-4 bg-[#2563EB] text-white font-black text-sm uppercase tracking-wider font-mono border-3 border-[#09090B] neo-shadow hover:-translate-x-0.5 hover:-translate-y-0.5 hover:shadow-[6px_6px_0px_#09090B] active:translate-x-0 active:translate-y-0 active:shadow-[2px_2px_0px_#09090B] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  <span>{loading ? 'MEMPROSES & MENYIMPAN KE FIRESTORE...' : 'KIRIM PESAN SEKARANG'}</span>
                </button>
              </form>
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
};
