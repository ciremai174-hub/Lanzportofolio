import React, { useEffect } from 'react';
import { motion, Variants } from 'motion/react';
import { smoothEase, slickEase } from './motion/MotionText';

interface IntroLoaderProps {
  onComplete: () => void;
  brandName?: string;
}

export const IntroLoader: React.FC<IntroLoaderProps> = ({ onComplete, brandName = 'Lanz' }) => {
  // Brand can come from Firestore as either 'Lanz' or 'LanzPortofolio'.
  // Remove the suffix here because the intro renders 'Portofolio' separately.
  const brandFirst = brandName.replace(/portofolio$/i, '').trim() || 'Lanz';
  const brandSecond = 'Portofolio';

  useEffect(() => {
    // Automatically transition to the home page smoothly after 1.85 seconds
    const timer = setTimeout(() => {
      onComplete();
    }, 1850);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === ' ' || e.key === 'Enter') {
        onComplete();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      clearTimeout(timer);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [onComplete]);

  // Silky smooth staggered letter animation
  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.04,
        delayChildren: 0.12,
      },
    },
  };

  const letterVariants: Variants = {
    hidden: {
      opacity: 0,
      y: 35,
      filter: 'blur(6px)',
      scale: 0.92,
    },
    visible: {
      opacity: 1,
      y: 0,
      filter: 'blur(0px)',
      scale: 1,
      transition: {
        duration: 0.75,
        ease: slickEase,
      },
    },
  };

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{
        opacity: 0,
        scale: 0.985,
        filter: 'blur(10px)',
        transition: {
          duration: 0.65,
          ease: [0.22, 1, 0.36, 1],
        },
      }}
      onClick={onComplete}
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#09090B] cursor-pointer select-none overflow-hidden"
    >
      {/* Subtle Ambient Radial Glow */}
      <motion.div
        initial={{ opacity: 0, scale: 0.7 }}
        animate={{ opacity: 0.22, scale: 1.15 }}
        transition={{ duration: 1.5, ease: 'easeOut' }}
        className="absolute w-[500px] h-[500px] rounded-full bg-[#2563EB]/25 blur-[120px] pointer-events-none"
      />

      {/* Main Minimalist Typography: ONLY "LanzPortofolio" */}
      <div className="relative z-10 flex flex-col items-center">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex items-center text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight font-['Space_Grotesk'] leading-none"
        >
          {/* "Lanz" in Pure White */}
          <span className="inline-flex overflow-hidden py-2">
            {brandFirst.split('').map((char, i) => (
              <motion.span
                key={`f-${i}`}
                variants={letterVariants}
                className="inline-block text-white"
              >
                {char}
              </motion.span>
            ))}
          </span>

          {/* "Portofolio" in Electric Blue */}
          <span className="inline-flex overflow-hidden py-2">
            {brandSecond.split('').map((char, i) => (
              <motion.span
                key={`s-${i}`}
                variants={letterVariants}
                className="inline-block text-[#2563EB] drop-shadow-[2px_2px_0px_#FFFFFF]"
              >
                {char}
              </motion.span>
            ))}
          </span>
        </motion.div>

        {/* Minimalist Underline Sweep */}
        <motion.div
          initial={{ width: 0, opacity: 0 }}
          animate={{ width: '100%', opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
          className="h-[3px] bg-gradient-to-r from-transparent via-[#2563EB] to-transparent mt-3 max-w-[280px]"
        />

        {/* Subtle touch indicator */}
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.35 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="mt-6 text-[11px] font-mono tracking-widest text-zinc-400 uppercase"
        >
          Klik untuk lewati
        </motion.span>
      </div>
    </motion.div>
  );
};
