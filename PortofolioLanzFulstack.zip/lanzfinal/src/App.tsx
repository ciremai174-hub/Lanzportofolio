import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { PortfolioData } from './types';
import { initialPortfolioData } from '../server/defaultData';
import { firestoreService } from './services/firestoreService';

import { IntroLoader } from './components/IntroLoader';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AlbumGallery } from './components/AlbumGallery';
import { SkillsSection } from './components/SkillsSection';
import { ProfileSection } from './components/ProfileSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { AdminPortal } from './components/admin/AdminPortal';

export default function App() {
  const [portfolioData, setPortfolioData] = useState<PortfolioData>(initialPortfolioData);
  const [loading, setLoading] = useState(true);
  const [showIntro, setShowIntro] = useState(true);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  // Check if current route matches the exclusive Admin Route: /LanzPortofolio or #LanzPortofolio
  const checkIsAdminRoute = () => {
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();

    return (
      path === '/lanzportofolio' ||
      path === '/lanzportofolio/' ||
      hash === '#lanzportofolio' ||
      hash === '#/lanzportofolio'
    );
  };

  // Load portfolio from Firestore & real-time sync
  useEffect(() => {
    const fetchPortfolio = async () => {
      try {
        const data = await firestoreService.getPortfolioData();
        if (data && data.hero) {
          setPortfolioData(data);
        }
      } catch (err) {
        console.warn('Menggunakan data fallback default:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPortfolio();

    // Subscribe to live Firestore updates
    const unsubscribe = firestoreService.subscribePortfolio((updated) => {
      if (updated && updated.hero) {
        setPortfolioData(updated);
      }
    });

    // Initial check for exclusive admin path
    if (checkIsAdminRoute()) {
      setIsAdminOpen(true);
      setShowIntro(false); // Direct access to admin portal without intro delay
    }

    // Listen to history navigation and hash change
    const handleLocationChange = () => {
      if (checkIsAdminRoute()) {
        setIsAdminOpen(true);
        setShowIntro(false);
      } else {
        setIsAdminOpen(false);
      }
    };

    window.addEventListener('popstate', handleLocationChange);
    window.addEventListener('hashchange', handleLocationChange);

    return () => {
      unsubscribe();
      window.removeEventListener('popstate', handleLocationChange);
      window.removeEventListener('hashchange', handleLocationChange);
    };
  }, []);

  const handleUpdatePortfolio = (newData: PortfolioData) => {
    setPortfolioData(newData);
  };

  const handleCloseAdmin = () => {
    setIsAdminOpen(false);
    // Return smoothly to public home route
    window.history.pushState({}, '', '/');
  };

  const handleReplayIntro = () => {
    setShowIntro(true);
  };

  // Apply configurable page metadata.
  useEffect(() => {
    const cfg = portfolioData.siteConfig;
    if (cfg.pageTitle) document.title = cfg.pageTitle;
    let meta = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    if (cfg.pageDescription) meta.content = cfg.pageDescription;
  }, [portfolioData.siteConfig]);

  // Apply favicon configured from CMS. Admin route remains accessible during maintenance.
  useEffect(() => {
    const faviconUrl = portfolioData.siteConfig.faviconUrl?.trim();
    let link = document.querySelector('link[rel~=' + JSON.stringify('icon') + ']') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    if (faviconUrl) link.href = faviconUrl;
  }, [portfolioData.siteConfig.faviconUrl]);

  // 1. EXCLUSIVE ADMIN ROUTE (domain/LanzPortofolio)
  // Renders the dedicated Admin Login or Dashboard directly, NOT the public page!
  if (isAdminOpen) {
    return (
      <AdminPortal
        portfolioData={portfolioData}
        onUpdatePortfolio={handleUpdatePortfolio}
        onClose={handleCloseAdmin}
      />
    );
  }

  // 2. PUBLIC MAINTENANCE SCREEN. Admin route above stays available for authorized admins.
  const cfg = portfolioData.siteConfig;
  if (cfg.maintenanceMode) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6 py-16" style={{ backgroundColor: cfg.backgroundColor || '#F8FAFC', color: cfg.textColor || '#09090B' }}>
        <div className="max-w-xl w-full text-center border-2 border-current rounded-3xl p-8 sm:p-12 shadow-2xl">
          <div className="mx-auto mb-6 h-16 w-16 rounded-2xl flex items-center justify-center text-white text-2xl font-black" style={{ backgroundColor: cfg.accentColor || '#2563EB' }}>L</div>
          <p className="text-xs font-bold tracking-[.25em] uppercase opacity-60 mb-3">Under Maintenance</p>
          <h1 className="text-3xl sm:text-4xl font-black mb-4">Website sedang diperbarui</h1>
          <p className="text-base sm:text-lg leading-7 opacity-75">{cfg.maintenanceMessage || 'Kami sedang melakukan pembaruan agar pengalaman kamu lebih baik. Silakan kembali sebentar lagi.'}</p>
        </div>
      </div>
    );
  }

  // 3. PUBLIC PORTFOLIO VIEW (domain/)
  const defaults = ['hero', 'album', 'skills', 'profile', 'contact'];
  const customSections = cfg.customSections || [];
  const allSectionIds = [...defaults, ...customSections.map((section) => section.id)];
  const sectionOrder = [...new Set([...(cfg.sectionOrder || []), ...allSectionIds])].filter((x) => allSectionIds.includes(x));
  const hiddenSections = cfg.hiddenSections || [];
  const sectionNodes: Record<string, React.ReactNode> = {
    hero: <HeroSection data={portfolioData.hero} pageCopy={cfg.pageCopy || {}} />,
    album: <AlbumGallery items={portfolioData.album} pageCopy={cfg.pageCopy || {}} />,
    skills: <SkillsSection skills={portfolioData.skills} pageCopy={cfg.pageCopy || {}} />,
    profile: <ProfileSection data={portfolioData.profile} pageCopy={cfg.pageCopy || {}} />,
    contact: <ContactSection siteConfig={portfolioData.siteConfig} socialLinks={portfolioData.socialLinks} pageCopy={cfg.pageCopy || {}} />,
    ...Object.fromEntries(customSections.map((section) => [section.id, section.visible === false ? null : (
      <section id={section.id} key={section.id} className="px-4 sm:px-6 lg:px-8 py-16 sm:py-24" style={{ backgroundColor: section.backgroundColor || 'transparent' }}>
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-5">
            {section.eyebrow && <p className="text-xs font-black uppercase tracking-[.2em] text-blue-600">{section.eyebrow}</p>}
            {section.title && <h2 className="text-3xl sm:text-5xl font-black tracking-tight">{section.title}</h2>}
            {section.body && <p className="text-base sm:text-lg leading-8 whitespace-pre-line opacity-80">{section.body}</p>}
            {section.buttonText && section.buttonUrl && <a href={section.buttonUrl} className="inline-flex items-center px-5 py-3 bg-blue-600 text-white font-bold border-2 border-current hover:opacity-90 transition">{section.buttonText}</a>}
          </div>
          {section.imageUrl && <img src={section.imageUrl} alt={section.title || 'Gambar section'} loading="lazy" className="w-full max-h-[480px] object-cover rounded-2xl border border-black/10" />}
        </div>
      </section>
    )])) ,
  };
  return (
    <div
      className="min-h-screen font-sans neo-grid-bg selection:text-white flex flex-col"
      style={{
        backgroundColor: cfg.backgroundColor || '#F8FAFC',
        color: cfg.textColor || '#09090B',
        ['--site-bg' as any]: cfg.backgroundColor || '#F8FAFC',
        ['--site-text' as any]: cfg.textColor || '#09090B',
        ['--site-accent' as any]: cfg.accentColor || '#2563EB',
      }}
    >
      {cfg.customCss && <style data-admin-custom-css>{cfg.customCss}</style>}
      {/* Framer Motion Intro Animation */}
      <AnimatePresence>
        {showIntro && <IntroLoader brandName={portfolioData.navigation.brandName} onComplete={() => setShowIntro(false)} />}
      </AnimatePresence>

      {/* Sticky Neo-Brutalism Navbar */}
      <Navbar
        data={portfolioData.navigation}
        siteConfig={portfolioData.siteConfig}
        onReplayIntro={handleReplayIntro}
      />

      {/* Main Portfolio Content: order and visibility are admin-configurable */}
      <main className="flex-1">
        {sectionOrder.filter((key) => !hiddenSections.includes(key)).map((key) => (
          <React.Fragment key={key}>{sectionNodes[key]}</React.Fragment>
        ))}
      </main>

      {/* Neo-Brutalist Footer (Public Isolation: No Admin Triggers) */}
      <Footer
        siteConfig={portfolioData.siteConfig}
        navigation={portfolioData.navigation}
        socialLinks={portfolioData.socialLinks}
        pageCopy={cfg.pageCopy || {}}
      />
    </div>
  );
}
