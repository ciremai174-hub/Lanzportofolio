import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot,
  writeBatch,
} from 'firebase/firestore';
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import { db, auth, googleProvider, handleFirestoreError, OperationType } from '../lib/firebase';
import { PortfolioData, ContactMessage, AdminUser } from '../types';
import { initialPortfolioData } from '../../server/defaultData';

export const firestoreService = {
  // Public & Admin: Fetch full portfolio data
  async getPortfolioData(): Promise<PortfolioData> {
    try {
      const settingsRef = doc(db, 'settings', 'portfolio');
      const settingsSnap = await getDoc(settingsRef);

      let portfolio: PortfolioData = JSON.parse(JSON.stringify(initialPortfolioData));

      if (settingsSnap.exists()) {
        const settingsData = settingsSnap.data() as Partial<PortfolioData>;
        if (settingsData.hero) portfolio.hero = settingsData.hero as any;
        if (settingsData.navigation) portfolio.navigation = settingsData.navigation as any;
        if (settingsData.profile) portfolio.profile = settingsData.profile as any;
        if (settingsData.siteConfig) portfolio.siteConfig = settingsData.siteConfig as any;
        // Canonical settings document is authoritative, including intentionally empty arrays.
        if (Array.isArray((settingsData as any).album)) portfolio.album = (settingsData as any).album;
        if (Array.isArray((settingsData as any).skills)) portfolio.skills = (settingsData as any).skills;
        if (Array.isArray((settingsData as any).socialLinks)) portfolio.socialLinks = (settingsData as any).socialLinks;
      }

      // Fetch projects/album from /projects collection
      try {
        const projectsSnap = await getDocs(collection(db, 'projects'));
        const canonical = settingsSnap.exists() ? settingsSnap.data() : {};
        if (!Array.isArray((canonical as any).album) && !projectsSnap.empty) {
          portfolio.album = projectsSnap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              title: data.title || '',
              description: data.description || '',
              category: data.category || '',
              imageUrl: data.imageUrl || '',
              tags: Array.isArray(data.tags) ? data.tags : [],
              date: data.date || '',
              featured: !!data.featured,
            };
          });
        }
      } catch (err) {
        console.warn('Projects fallback notice:', err);
      }

      // Fetch skills from /skills collection
      try {
        const skillsSnap = await getDocs(collection(db, 'skills'));
        const canonical = settingsSnap.exists() ? settingsSnap.data() : {};
        if (!Array.isArray((canonical as any).skills) && !skillsSnap.empty) {
          portfolio.skills = skillsSnap.docs.map((d) => {
            const data = d.data();
            return {
              category: data.category || '',
              description: data.description || '',
              items: Array.isArray(data.items) ? data.items : [],
            };
          });
        }
      } catch (err) {
        console.warn('Skills fallback notice:', err);
      }

      // Fetch socials from /socials collection
      try {
        const socialsSnap = await getDocs(collection(db, 'socials'));
        const canonical = settingsSnap.exists() ? settingsSnap.data() : {};
        if (!Array.isArray((canonical as any).socialLinks) && !socialsSnap.empty) {
          portfolio.socialLinks = socialsSnap.docs.map((d) => {
            const data = d.data();
            return {
              id: d.id,
              platform: data.platform || 'website',
              label: data.label || '',
              url: data.url || '',
              active: data.active !== false,
            };
          });
        }
      } catch (err) {
        console.warn('Socials fallback notice:', err);
      }

      return portfolio;
    } catch (error) {
      console.warn('Error fetching Firestore portfolio, fallback to initial:', error);
      return initialPortfolioData;
    }
  },

  // Real-time listener for public / admin live updates
  subscribePortfolio(callback: (data: PortfolioData) => void): () => void {
    const settingsRef = doc(db, 'settings', 'portfolio');
    return onSnapshot(
      settingsRef,
      async (snap) => {
        if (snap.exists()) {
          const fresh = await this.getPortfolioData();
          callback(fresh);
        }
      },
      (error) => {
        console.warn('Portfolio subscription notice:', error);
      }
    );
  },

  // Admin: Save full portfolio data to Firestore
  async savePortfolioData(data: PortfolioData): Promise<void> {
    const path = 'settings/portfolio';
    try {
      // Canonical document owns all public content. Empty arrays are meaningful.
      await setDoc(doc(db, 'settings', 'portfolio'), {
        hero: data.hero,
        navigation: data.navigation,
        profile: data.profile,
        siteConfig: data.siteConfig,
        album: data.album ?? [],
        skills: data.skills ?? [],
        socialLinks: data.socialLinks ?? [],
        updatedAt: new Date().toISOString(),
      });

      // Keep legacy collections synchronized and delete removed records.
      const syncCollection = async (
        name: string,
        entries: any[],
        idFor: (entry: any, index: number) => string,
        serialize: (entry: any, index: number) => Record<string, any>
      ) => {
        const existing = await getDocs(collection(db, name));
        const wanted = new Set(entries.map((entry, index) => idFor(entry, index)));
        const batch = writeBatch(db);
        existing.docs.forEach((snapshot) => {
          if (!wanted.has(snapshot.id)) batch.delete(snapshot.ref);
        });
        entries.forEach((entry, index) => {
          batch.set(doc(db, name, idFor(entry, index)), {
            ...serialize(entry, index),
            updatedAt: new Date().toISOString(),
          });
        });
        await batch.commit();
      };

      await syncCollection('projects', data.album ?? [],
        (item, i) => String(item.id || `project-${i + 1}`).toLowerCase().replace(/[^a-z0-9_-]/g, '-').slice(0, 100),
        (item) => ({ title: item.title || '', description: item.description || '', category: item.category || 'Tech', imageUrl: item.imageUrl || '', tags: item.tags || [], date: item.date || '', featured: !!item.featured })
      );
      await syncCollection('skills', data.skills ?? [],
        (item, i) => `skill-${i + 1}-${String(item.category || 'category').toLowerCase().replace(/[^a-z0-9_-]/g, '-').slice(0, 70)}`,
        (item, i) => ({ category: item.category || '', description: item.description || '', items: item.items || [], order: i })
      );
      await syncCollection('socials', data.socialLinks ?? [],
        (item, i) => String(item.id || item.platform || `social-${i + 1}`).toLowerCase().replace(/[^a-z0-9_-]/g, '-').slice(0, 100),
        (item) => ({ platform: item.platform, label: item.label, url: item.url, active: item.active })
      );
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  // Public: Send contact message to /messages
  async sendContactMessage(form: { name: string; email: string; subject: string; message: string }): Promise<void> {
    const path = 'messages';
    try {
      const messageId = `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      await setDoc(doc(db, 'messages', messageId), {
        name: form.name.slice(0, 100),
        email: form.email.slice(0, 150),
        subject: form.subject.slice(0, 200),
        message: form.message.slice(0, 3000),
        status: 'unread',
        createdAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },

  // Admin: Get contact messages
  async getMessages(): Promise<ContactMessage[]> {
    const path = 'messages';
    try {
      const q = query(collection(db, 'messages'), orderBy('createdAt', 'desc'));
      const snap = await getDocs(q);
      return snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as Omit<ContactMessage, 'id'>),
      }));
    } catch (error) {
      // Fallback query if ordering without index
      try {
        const snap = await getDocs(collection(db, 'messages'));
        const msgs = snap.docs.map((d) => ({
          id: d.id,
          ...(d.data() as Omit<ContactMessage, 'id'>),
        }));
        return msgs.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      } catch (err2) {
        handleFirestoreError(err2, OperationType.LIST, path);
        return [];
      }
    }
  },

  // Admin: Update message status
  async updateMessageStatus(messageId: string, status: 'unread' | 'read' | 'replied'): Promise<void> {
    const path = `messages/${messageId}`;
    try {
      await updateDoc(doc(db, 'messages', messageId), { status });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  },

  // Admin: Delete message
  async deleteMessage(messageId: string): Promise<void> {
    const path = `messages/${messageId}`;
    try {
      await deleteDoc(doc(db, 'messages', messageId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Admin: Get admins list
  async getAdmins(): Promise<AdminUser[]> {
    const path = 'admins';
    try {
      const snap = await getDocs(collection(db, 'admins'));
      return snap.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          username: data.email || data.username || d.id,
          role: data.role || 'admin',
          createdAt: data.createdAt,
        };
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  },

  // Admin: Add admin record
  async addAdmin(email: string, role: 'superadmin' | 'admin'): Promise<void> {
    const path = 'admins';
    try {
      const adminId = email.trim().toLowerCase();
      await setDoc(doc(db, 'admins', adminId), {
        email: email.trim().toLowerCase(),
        role,
        createdAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  },

  // Admin: Delete admin record
  async deleteAdmin(adminId: string): Promise<void> {
    const path = `admins/${adminId}`;
    try {
      await deleteDoc(doc(db, 'admins', adminId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  },

  // Single-owner allowlist. Firestore Security Rules must use the same email allowlist.
  // This avoids a false 'not registered' result when the /admins document has not been created.
  async isAuthorizedAdmin(email: string | null | undefined): Promise<boolean> {
    return (email || '').trim().toLowerCase() === 'lanzelit18@gmail.com';
  },

  // Authentication Helpers
  async signInWithGoogle(): Promise<User> {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  },

  async signInWithEmail(email: string, pass: string): Promise<User> {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    return result.user;
  },

  async signUpWithEmail(email: string, pass: string): Promise<User> {
    const result = await createUserWithEmailAndPassword(auth, email, pass);
    return result.user;
  },

  async logout(): Promise<void> {
    await signOut(auth);
  },

  onAuthState(callback: (user: User | null) => void): () => void {
    return onAuthStateChanged(auth, callback);
  },
};
